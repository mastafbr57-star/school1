import React, { useState } from 'react';
import { Teacher, Student, SchoolInfo, CardTheme } from '../types';
import { QrCode, Download, Printer, Palette, Sparkles, Loader2 } from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

interface IdCardPreviewProps {
  selectedRecord: Teacher | Student | null;
  schoolInfo: SchoolInfo;
  theme: CardTheme;
  setTheme: (t: CardTheme) => void;
  onOpenBatchPrint: () => void;
}

export const IdCardPreview: React.FC<IdCardPreviewProps> = ({
  selectedRecord,
  schoolInfo,
  theme,
  setTheme,
  onOpenBatchPrint,
}) => {
  const [isExporting, setIsExporting] = useState(false);
  const isTeacher = selectedRecord ? 'subject' in selectedRecord : true;

  const handleExportPDF = () => {
    alert("Please select 'Save as PDF' in the destination dropdown of the print dialog.");
    window.print();
  };

  // Theme configuration dictionaries
  const themeStyles = {
    blue: {
      headerBg: 'bg-blue-900',
      headerText: 'text-white',
      accent: 'text-blue-600',
      border: 'border-blue-900',
      badgeBg: 'bg-blue-50 text-blue-700',
      decorCircle1: 'bg-blue-50',
    },
    green: {
      headerBg: 'bg-emerald-900',
      headerText: 'text-white',
      accent: 'text-emerald-600',
      border: 'border-emerald-900',
      badgeBg: 'bg-emerald-50 text-emerald-700',
      decorCircle1: 'bg-emerald-50',
    },
    dark: {
      headerBg: 'bg-gray-900',
      headerText: 'text-white',
      accent: 'text-gray-900',
      border: 'border-gray-900',
      badgeBg: 'bg-gray-100 text-gray-800',
      decorCircle1: 'bg-gray-100',
    },
    maroon: {
      headerBg: 'bg-rose-950',
      headerText: 'text-white',
      accent: 'text-rose-800',
      border: 'border-rose-950',
      badgeBg: 'bg-rose-50 text-rose-900',
      decorCircle1: 'bg-rose-50',
    },
    amber: {
      headerBg: 'bg-amber-800',
      headerText: 'text-white',
      accent: 'text-amber-700',
      border: 'border-amber-800',
      badgeBg: 'bg-amber-50 text-amber-900',
      decorCircle1: 'bg-amber-50',
    },
  };

  const activeTheme = themeStyles[theme];

  return (
    <section className="w-full lg:w-[420px] xl:w-[460px] flex flex-col flex-shrink-0">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
          <span>🪪</span> Live Card Preview
        </h2>

        {/* Theme Picker */}
        <div className="flex items-center gap-1.5 bg-gray-100 p-1 rounded-xl">
          <Palette className="w-3.5 h-3.5 text-gray-500 ml-1" />
          {(['blue', 'green', 'dark', 'maroon', 'amber'] as CardTheme[]).map((t) => (
            <button
              key={t}
              onClick={() => setTheme(t)}
              title={`${t.charAt(0).toUpperCase() + t.slice(1)} Template`}
              className={`w-5 h-5 rounded-md transition-all ${
                t === 'blue'
                  ? 'bg-blue-900'
                  : t === 'green'
                  ? 'bg-emerald-900'
                  : t === 'dark'
                  ? 'bg-gray-900'
                  : t === 'maroon'
                  ? 'bg-rose-950'
                  : 'bg-amber-800'
              } ${theme === t ? 'ring-2 ring-blue-500 ring-offset-1 scale-110' : 'opacity-70 hover:opacity-100'}`}
            />
          ))}
        </div>
      </div>

      {/* Preview Box with Prompt's Clean Minimalism decorative circles */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-gray-200 shadow-xl flex flex-col items-center justify-center flex-1 min-h-[480px] relative overflow-hidden">
        {/* Decorative Circles */}
        <div className={`absolute -top-10 -right-10 w-40 h-40 rounded-full transition-colors ${activeTheme.decorCircle1}`}></div>
        <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-gray-50 rounded-full"></div>

        {selectedRecord ? (
          /* Actual Printable Card Container */
          <div
            id="printable-single-card"
            className="w-64 sm:w-[270px] bg-white border border-gray-300 rounded-xl overflow-hidden shadow-2xl flex flex-col ring-8 ring-white relative z-10 transition-all duration-300 transform hover:-translate-y-1"
          >
            {/* Card Header */}
            <div className={`${activeTheme.headerBg} p-3.5 ${activeTheme.headerText} text-center transition-colors relative`}>
              <div className="w-10 h-10 bg-white/20 rounded-full mx-auto mb-1 flex items-center justify-center font-bold text-base shadow-xs backdrop-blur-xs">
                {schoolInfo.logo}
              </div>
              <p className="text-[11px] font-black uppercase tracking-widest leading-tight">{schoolInfo.name}</p>
              <span className="text-[8px] opacity-80 uppercase tracking-wider block mt-0.5">
                {isTeacher ? 'Faculty Identity Card' : 'Student Identity Card'}
              </span>
            </div>

            {/* Card Body */}
            <div className="flex-1 p-4 flex flex-col items-center bg-white text-gray-900">
              {/* Photo Frame */}
              <div
                className={`w-24 h-24 sm:w-26 sm:h-26 bg-gray-100 rounded-lg border-2 ${activeTheme.border} mb-3 overflow-hidden flex items-center justify-center font-bold text-gray-300 relative shadow-md`}
              >
                {selectedRecord.photo ? (
                  <img src={selectedRecord.photo} alt={selectedRecord.name} className="w-full h-full object-cover" />
                ) : (
                  <span className="text-3xl">{isTeacher ? '👤' : '👨‍🎓'}</span>
                )}
                {!isTeacher && (
                  <span className="absolute bottom-0 inset-x-0 bg-black/70 text-white text-[8px] font-bold py-0.5 text-center uppercase">
                    {(selectedRecord as Student).bloodGroup} Blood
                  </span>
                )}
              </div>

              {/* Name & Role */}
              <h4 className="font-black text-gray-900 uppercase text-sm text-center leading-tight">
                {selectedRecord.name}
              </h4>
              <p className={`${activeTheme.accent} font-bold text-[10px] uppercase mb-3 text-center transition-colors`}>
                {isTeacher ? (selectedRecord as Teacher).designation : `Class: ${(selectedRecord as Student).classSection}`}
              </p>

              {/* Attributes Diction */}
              <div className="w-full space-y-1.5 mb-4 px-1">
                <div className="flex justify-between text-[9px] border-b border-gray-100 pb-0.5">
                  <span className="text-gray-400 font-bold uppercase">{isTeacher ? 'Teacher ID' : 'Student ID'}</span>
                  <span className="font-mono font-black text-gray-800">{selectedRecord.id}</span>
                </div>

                {isTeacher ? (
                  <>
                    <div className="flex justify-between text-[9px] border-b border-gray-100 pb-0.5">
                      <span className="text-gray-400 font-bold uppercase">Subject</span>
                      <span className="font-bold text-gray-800 truncate max-w-[120px] text-right">
                        {(selectedRecord as Teacher).subject}
                      </span>
                    </div>
                    <div className="flex justify-between text-[9px] border-b border-gray-100 pb-0.5">
                      <span className="text-gray-400 font-bold uppercase">In-Charge</span>
                      <span className="font-bold text-gray-800 truncate max-w-[120px] text-right">
                        {(selectedRecord as Teacher).classIncharge}
                      </span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex justify-between text-[9px] border-b border-gray-100 pb-0.5">
                      <span className="text-gray-400 font-bold uppercase">Roll Number</span>
                      <span className="font-bold text-gray-800">{(selectedRecord as Student).rollNumber}</span>
                    </div>
                    <div className="flex justify-between text-[9px] border-b border-gray-100 pb-0.5">
                      <span className="text-gray-400 font-bold uppercase">Emergency</span>
                      <span className="font-mono font-bold text-gray-800">{(selectedRecord as Student).emergencyContact}</span>
                    </div>
                  </>
                )}

                <div className="flex justify-between text-[9px] border-b border-gray-100 pb-0.5">
                  <span className="text-gray-400 font-bold uppercase">Valid Thru</span>
                  <span className="font-bold text-emerald-700">{schoolInfo.validity}</span>
                </div>
              </div>

              {/* QR Code & Barcode Simulation */}
              <div className="w-full flex items-center justify-between gap-3 bg-gray-50/80 p-2 rounded-lg border border-gray-100">
                <div className="bg-white p-1 rounded border border-gray-200 shadow-2xs">
                  <QrCode className="w-10 h-10 text-gray-800" />
                </div>
                <div className="flex-1 flex flex-col items-center">
                  <div className="h-7 w-full bg-transparent flex items-center justify-center gap-0.5 overflow-hidden px-1">
                    <div className="w-0.5 h-full bg-black"></div>
                    <div className="w-1 h-full bg-black"></div>
                    <div className="w-0.5 h-full bg-black"></div>
                    <div className="w-1.5 h-full bg-black"></div>
                    <div className="w-0.5 h-full bg-black"></div>
                    <div className="w-1 h-full bg-black"></div>
                    <div className="w-0.5 h-full bg-black"></div>
                    <div className="w-2 h-full bg-black"></div>
                    <div className="w-0.5 h-full bg-black"></div>
                    <div className="w-1 h-full bg-black"></div>
                  </div>
                  <span className="text-[7px] font-mono tracking-widest text-gray-600 mt-0.5">
                    *{selectedRecord.id.replace('-', '')}894*
                  </span>
                </div>
              </div>
            </div>

            {/* Card Footer */}
            <div className="bg-gray-50 border-t border-gray-200 p-2 text-center">
              <p className="text-[7px] text-gray-500 font-medium leading-relaxed">
                {schoolInfo.address}
                <br />
                {schoolInfo.phone} | {schoolInfo.email}
              </p>
            </div>
          </div>
        ) : (
          <div className="text-center py-12 z-10">
            <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl mx-auto flex items-center justify-center text-2xl mb-3 shadow-sm">
              <Sparkles className="w-8 h-8 text-blue-500" />
            </div>
            <p className="font-bold text-gray-800">Select a Record</p>
            <p className="text-xs text-gray-400 mt-1 max-w-[200px]">
              Click &apos;Select for ID&apos; on any teacher or student card to preview their printable badge.
            </p>
          </div>
        )}
      </div>

      {/* Action Buttons matching prompt: 📥 Export PDF / 🖨️ Print Batch */}
      <div className="mt-4 grid grid-cols-2 gap-3">
        <button
          onClick={handleExportPDF}
          disabled={!selectedRecord || isExporting}
          className={`bg-white border border-gray-200 py-3 rounded-xl text-xs font-bold shadow-xs transition-all flex items-center justify-center gap-2 ${
            selectedRecord && !isExporting ? 'hover:bg-gray-50 text-gray-800 cursor-pointer' : 'opacity-50 cursor-not-allowed text-gray-400'
          }`}
        >
          {isExporting ? <Loader2 className="w-4 h-4 text-blue-600 animate-spin" /> : <Download className="w-4 h-4 text-blue-600" />}
          <span>{isExporting ? 'Saving...' : '📄 Save PDF'}</span>
        </button>

        <button
          onClick={onOpenBatchPrint}
          className="bg-blue-600 text-white py-3 rounded-xl text-xs font-bold shadow-sm hover:bg-blue-700 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <Printer className="w-4 h-4" />
          <span>🖨️ Print Batch IDs</span>
        </button>
      </div>
    </section>
  );
};
