import React, { useState } from 'react';
import { Teacher, Student, SchoolInfo, CardTheme } from '../types';
import { X, Printer, QrCode, Download, Loader2 } from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

interface PrintBatchModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: (Teacher | Student)[];
  schoolInfo: SchoolInfo;
  theme: CardTheme;
}

export const PrintBatchModal: React.FC<PrintBatchModalProps> = ({ isOpen, onClose, records, schoolInfo, theme }) => {
  const [isExporting, setIsExporting] = useState(false);

  if (!isOpen) return null;

  const handleExportPDF = () => {
    alert("Please select 'Save as PDF' in the destination dropdown of the print dialog.");
    window.print();
  };

  const handlePrint = () => {
    if (window.self !== window.top) {
      alert("Browser printing might be blocked in the preview mode. Please use 'Export as PDF' or open the app in a new tab.");
    }
    window.print();
  };

  const themeStyles = {
    blue: { headerBg: 'bg-[#1e3a8a]', text: 'text-white', accent: 'text-[#2563eb]', border: 'border-[#1e3a8a]' },
    green: { headerBg: 'bg-[#064e3b]', text: 'text-white', accent: 'text-[#059669]', border: 'border-[#064e3b]' },
    dark: { headerBg: 'bg-[#111827]', text: 'text-white', accent: 'text-[#111827]', border: 'border-[#111827]' },
    maroon: { headerBg: 'bg-[#4c0519]', text: 'text-white', accent: 'text-[#9f1239]', border: 'border-[#4c0519]' },
    amber: { headerBg: 'bg-[#92400e]', text: 'text-white', accent: 'text-[#b45309]', border: 'border-[#92400e]' },
  }[theme];

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex flex-col overflow-y-auto">
      {/* Non-printable Screen Topbar */}
      <div className="bg-gray-900 text-white p-4 flex items-center justify-between sticky top-0 z-50 print:hidden shadow-lg">
        <div className="flex items-center gap-3">
          <span className="text-2xl">🖨️</span>
          <div>
            <h3 className="font-bold text-base">Batch ID Card Print Preview</h3>
            <p className="text-xs text-gray-400">Ready to print {records.length} cards. Recommended settings: Margins None, Background Graphics ON.</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleExportPDF}
            disabled={isExporting}
            className={`px-5 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all ${
              isExporting ? 'bg-gray-700 text-gray-400 cursor-not-allowed' : 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer'
            }`}
          >
            {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
            <span>{isExporting ? 'Exporting...' : 'Export as PDF'}</span>
          </button>
          <button
            onClick={handlePrint}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Browser Print</span>
          </button>
          <button onClick={onClose} className="p-2 bg-gray-800 hover:bg-gray-700 rounded-xl text-gray-300">
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Printable Sheet Container */}
      <div className="p-8 print:p-0 flex-1 flex justify-center bg-gray-100 print:bg-white overflow-x-auto">
        <div id="printable-batch-container" className="max-w-[800px] w-full grid grid-cols-1 sm:grid-cols-2 gap-6 print:grid-cols-2 print:gap-4 print:w-full print:m-0">
          {records.map((rec) => {
            const isTeacher = 'subject' in rec;
            return (
              <div
                key={rec.id}
                className="w-[270px] h-[410px] mx-auto bg-white border border-gray-300 rounded-xl overflow-hidden shadow-md flex flex-col print:shadow-none print:border print:border-gray-400 page-break-inside-avoid"
              >
                {/* Header */}
                <div className={`${themeStyles.headerBg} p-3 text-white text-center`}>
                  <div className="w-8 h-8 bg-white/20 rounded-full mx-auto mb-1 flex items-center justify-center font-bold text-xs">
                    {schoolInfo.logo}
                  </div>
                  <p className="text-[10px] font-black uppercase tracking-widest leading-tight">{schoolInfo.name}</p>
                  <span className="text-[7px] opacity-80 uppercase tracking-wider block mt-0.5">
                    {isTeacher ? 'Faculty Identity Card' : 'Student Identity Card'}
                  </span>
                </div>

                {/* Body */}
                <div className="flex-1 p-3 flex flex-col items-center bg-white text-gray-900">
                  <div className={`w-20 h-20 bg-gray-100 rounded-lg border-2 ${themeStyles.border} mb-2 overflow-hidden flex items-center justify-center font-bold text-gray-300`}>
                    {rec.photo ? <img src={rec.photo} alt={rec.name} className="w-full h-full object-cover" /> : <span>👤</span>}
                  </div>
                  <h4 className="font-black text-gray-900 uppercase text-xs text-center leading-tight">{rec.name}</h4>
                  <p className={`${themeStyles.accent} font-bold text-[9px] uppercase mb-2 text-center`}>
                    {isTeacher ? (rec as Teacher).designation : `Grade ${(rec as Student).classSection}`}
                  </p>

                  <div className="w-full space-y-1 mb-3 px-2 text-[8px]">
                    <div className="flex justify-between border-b border-gray-100 pb-0.5">
                      <span className="text-gray-400 font-bold uppercase">ID</span>
                      <span className="font-mono font-bold">{rec.id}</span>
                    </div>
                    {isTeacher ? (
                      <div className="flex justify-between border-b border-gray-100 pb-0.5">
                        <span className="text-gray-400 font-bold uppercase">Subject</span>
                        <span className="font-bold truncate max-w-[100px]">{(rec as Teacher).subject}</span>
                      </div>
                    ) : (
                      <div className="flex justify-between border-b border-gray-100 pb-0.5">
                        <span className="text-gray-400 font-bold uppercase">Roll No</span>
                        <span className="font-bold">{(rec as Student).rollNumber}</span>
                      </div>
                    )}
                    <div className="flex justify-between border-b border-gray-100 pb-0.5">
                      <span className="text-gray-400 font-bold uppercase">Valid Thru</span>
                      <span className="font-bold">{schoolInfo.validity}</span>
                    </div>
                  </div>

                  {/* QR / Barcode simulation */}
                  <div className="w-full flex items-center justify-between gap-2 bg-gray-50 p-1.5 rounded border border-gray-100 mt-auto">
                    <QrCode className="w-7 h-7 text-gray-800" />
                    <div className="flex-1 flex flex-col items-center">
                      <div className="h-5 w-full bg-transparent flex items-center justify-center gap-0.5 overflow-hidden">
                        <div className="w-px h-full bg-black"></div>
                        <div className="w-1 h-full bg-black"></div>
                        <div className="w-0.5 h-full bg-black"></div>
                        <div className="w-1 h-full bg-black"></div>
                        <div className="w-px h-full bg-black"></div>
                        <div className="w-1.5 h-full bg-black"></div>
                      </div>
                      <span className="text-[6px] font-mono tracking-widest text-gray-600">*{rec.id}*</span>
                    </div>
                  </div>
                </div>

                {/* Footer */}
                <div className="bg-gray-50 border-t border-gray-200 p-1.5 text-center">
                  <p className="text-[6px] text-gray-500 font-medium leading-tight">{schoolInfo.address}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
