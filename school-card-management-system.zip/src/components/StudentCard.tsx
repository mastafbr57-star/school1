import React from 'react';
import { Student } from '../types';
import { Calendar, Eye, Edit2, Printer, MapPin, Phone, User, CheckCircle2, AlertTriangle, XCircle, BarChart2 } from 'lucide-react';

interface StudentCardProps {
  student: Student;
  onView: (student: Student) => void;
  onEdit: (student: Student) => void;
  onPrintId: (student: Student) => void;
  isSelectedForId: boolean;
}

export const StudentCard: React.FC<StudentCardProps> = ({
  student,
  onView,
  onEdit,
  onPrintId,
  isSelectedForId,
}) => {
  const getFeeBadge = () => {
    switch (student.feeStatus) {
      case 'paid':
        return (
          <span className="inline-flex items-center gap-1 text-emerald-700 bg-emerald-100 border border-emerald-200 px-2 py-0.5 rounded text-[11px] font-bold">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Paid ({student.feeMonth})
          </span>
        );
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1 text-amber-700 bg-amber-100 border border-amber-200 px-2 py-0.5 rounded text-[11px] font-bold">
            <AlertTriangle className="w-3 h-3 text-amber-600" /> Pending ({student.feeMonth})
          </span>
        );
      case 'overdue':
        return (
          <span className="inline-flex items-center gap-1 text-rose-700 bg-rose-100 border border-rose-200 px-2 py-0.5 rounded text-[11px] font-bold">
            <XCircle className="w-3 h-3 text-rose-600" /> Overdue ({student.feeMonth})
          </span>
        );
    }
  };

  const getAttendanceColor = (pct: number) => {
    if (pct >= 90) return 'text-emerald-600 font-bold';
    if (pct >= 75) return 'text-blue-600 font-bold';
    return 'text-rose-600 font-bold';
  };

  return (
    <div
      className={`bg-white p-5 rounded-2xl border transition-all duration-200 flex flex-col sm:flex-row items-start gap-5 shadow-xs hover:shadow-md relative ${
        isSelectedForId ? 'border-emerald-500 ring-2 ring-emerald-500/20 bg-emerald-50/10' : 'border-gray-200 hover:border-gray-300'
      }`}
    >
      {/* Student Photo */}
      <div className="w-24 h-24 sm:w-28 sm:h-28 bg-emerald-100 rounded-xl flex-shrink-0 flex items-center justify-center text-4xl overflow-hidden relative border border-emerald-200/60 shadow-inner group">
        {student.photo ? (
          <img
            src={student.photo}
            alt={student.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            referrerPolicy="no-referrer"
          />
        ) : (
          <span className="text-4xl">👨‍🎓</span>
        )}
        <div className="absolute top-1 left-1 bg-white/90 backdrop-blur-xs px-1.5 py-0.5 rounded text-[10px] font-black text-emerald-800 shadow-xs">
          {student.bloodGroup}
        </div>
      </div>

      {/* Details Grid */}
      <div className="flex-1 w-full grid grid-cols-1 sm:grid-cols-2 gap-y-2.5 gap-x-4 text-sm">
        {/* Name & ID Header */}
        <div className="col-span-1 sm:col-span-2 flex flex-wrap justify-between items-start border-b border-gray-100 pb-2 gap-2">
          <div>
            <h3 className="text-lg font-bold text-gray-900 flex items-center flex-wrap gap-2">
              {student.name}
              <span className="px-2 py-0.5 bg-blue-100 text-blue-800 rounded text-[10px] uppercase font-black tracking-wider border border-blue-200">
                Roll No: {student.rollNumber}
              </span>
              <span
                className={`px-2 py-0.5 rounded text-[10px] uppercase font-black tracking-wider ${
                  student.status === 'active'
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-gray-100 text-gray-600'
                }`}
              >
                {student.status === 'active' ? 'Active' : 'Inactive'}
              </span>
            </h3>
            <p className="text-xs text-gray-500 font-medium flex items-center gap-1 mt-0.5">
              <User className="w-3 h-3 text-gray-400" /> S/O {student.fatherName}
            </p>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-xs font-mono font-bold text-gray-700 bg-gray-100 px-2.5 py-1 rounded-md border border-gray-200">
              ID: {student.id}
            </span>
            <span className="text-[10px] text-gray-400 mt-0.5 font-medium flex items-center gap-1">
              🎂 DOB: {student.dob}
            </span>
          </div>
        </div>

        {/* Info Rows */}
        <div>
          <span className="text-gray-400 block text-[10px] uppercase font-bold tracking-wider">Class & Section</span>
          <span className="font-bold text-gray-900 text-base">{student.classSection}</span>
        </div>

        <div>
          <span className="text-gray-400 block text-[10px] uppercase font-bold tracking-wider">Fee Status</span>
          <div className="mt-0.5">{getFeeBadge()}</div>
        </div>

        <div>
          <span className="text-gray-400 block text-[10px] uppercase font-bold tracking-wider">Attendance</span>
          <span className={getAttendanceColor(student.attendancePercentage)}>
            {student.attendancePercentage}%{' '}
            <span className="text-xs text-gray-400 font-normal">
              ({student.attendancePercentage >= 90 ? 'Excellent' : student.attendancePercentage >= 75 ? 'Satisfactory' : 'Low'})
            </span>
          </span>
        </div>

        <div>
          <span className="text-gray-400 block text-[10px] uppercase font-bold tracking-wider flex items-center gap-1">
            <BarChart2 className="w-3 h-3 text-blue-500" /> Current Result
          </span>
          <span className="font-semibold text-gray-800">{student.resultSummary}</span>
        </div>

        {/* Address & Parent Contact */}
        <div className="col-span-1 sm:col-span-2 pt-1 flex flex-wrap items-center gap-4 text-xs text-gray-500 font-medium border-t border-gray-50">
          <span className="flex items-center gap-1 truncate max-w-sm" title={student.address}>
            <MapPin className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" /> {student.address}
          </span>
          <span className="flex items-center gap-1 ml-auto font-mono text-gray-600">
            <Phone className="w-3.5 h-3.5 text-gray-400" /> {student.parentContact}
          </span>
        </div>

        {/* Action Buttons matching prompt: [View] [Edit] [Print ID] */}
        <div className="col-span-1 sm:col-span-2 pt-3 flex flex-wrap gap-2 items-center justify-end border-t border-gray-100">
          <button
            onClick={() => onView(student)}
            className="px-3.5 py-1.5 border border-gray-200 rounded-xl text-xs font-bold text-gray-700 hover:bg-gray-50 hover:border-gray-300 transition-all flex items-center gap-1"
          >
            <Eye className="w-3.5 h-3.5 text-gray-500" />
            <span>View Details</span>
          </button>

          <button
            onClick={() => onEdit(student)}
            className="px-3.5 py-1.5 border border-gray-200 rounded-xl text-xs font-bold text-gray-700 hover:bg-gray-50 hover:border-gray-300 transition-all flex items-center gap-1"
          >
            <Edit2 className="w-3.5 h-3.5 text-gray-500" />
            <span>Edit</span>
          </button>

          <button
            onClick={() => onPrintId(student)}
            className="px-4 py-1.5 bg-gray-900 text-white hover:bg-black rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all flex items-center gap-1.5"
          >
            <Printer className="w-3.5 h-3.5 text-emerald-400" />
            <span>Print ID Card</span>
          </button>
        </div>
      </div>
    </div>
  );
};
