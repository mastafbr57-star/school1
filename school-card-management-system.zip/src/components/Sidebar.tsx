import React from 'react';
import { RecordType } from '../types';
import { LayoutDashboard, Users, GraduationCap, IdCard, BarChart3, School } from 'lucide-react';

export type TabType = 'dashboard' | 'teachers' | 'students' | 'attendance' | 'fees' | 'exams' | 'id-generator' | 'analytics';

interface SidebarProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  setRecordType: (type: RecordType) => void;
  teachersCount: number;
  studentsCount: number;
  schoolName?: string;
  setSchoolName?: (name: string) => void;
  schoolTagline?: string;
  setSchoolTagline?: (tagline: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  setRecordType,
  teachersCount,
  studentsCount,
  schoolName = 'EduCard Pro',
  setSchoolName,
  schoolTagline = 'PAKISTAN SCHOOL SYS',
  setSchoolTagline,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, emoji: '🏠' },
    { id: 'teachers', label: 'Teachers', icon: Users, emoji: '👨‍🏫', badge: teachersCount },
    { id: 'students', label: 'Students', icon: GraduationCap, emoji: '👨‍🎓', badge: studentsCount },
    { id: 'attendance', label: 'Attendance', icon: Users, emoji: '📅' },
    { id: 'fees', label: 'Fee Management', icon: Users, emoji: '💰' },
    { id: 'exams', label: 'Exams & Results', icon: Users, emoji: '📝' },
    { id: 'id-generator', label: 'ID Generator', icon: IdCard, emoji: '🪪' },
    { id: 'analytics', label: 'Analytics', icon: BarChart3, emoji: '📊' },
  ] as const;

  return (
    <aside className="w-full md:w-64 bg-white border-r border-gray-200 flex flex-col flex-shrink-0 z-10 print:hidden">
      {/* Brand Header */}
      <div className="p-6 flex items-center gap-3 border-b md:border-b-0 border-gray-100">
        <div className="w-10 h-10 shrink-0 bg-blue-600 rounded-lg flex items-center justify-center text-white shadow-md shadow-blue-500/20">
          <School className="w-6 h-6" />
        </div>
        <div className="flex-1 min-w-0">
          <input
            type="text"
            value={schoolName}
            onChange={(e) => setSchoolName?.(e.target.value)}
            className="font-bold text-xl tracking-tight uppercase block text-gray-900 w-full bg-transparent border-none p-0 focus:ring-0 truncate"
            placeholder="School Name"
          />
          <input
            type="text"
            value={schoolTagline}
            onChange={(e) => setSchoolTagline?.(e.target.value)}
            className="text-[10px] font-medium text-gray-400 block tracking-wider w-full bg-transparent border-none p-0 focus:ring-0 truncate mt-0.5"
            placeholder="Tagline / Location"
          />
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-2 md:py-4 space-y-1 overflow-y-auto flex md:flex-col gap-1 md:gap-0">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                if (item.id === 'teachers') setRecordType('teacher');
                if (item.id === 'students') setRecordType('student');
              }}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl font-medium text-sm transition-all text-left ${
                isActive
                  ? 'bg-blue-50 text-blue-600 font-semibold shadow-sm'
                  : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <div className="flex items-center">
                <span className="mr-3 text-base">{item.emoji}</span>
                <span>{item.label}</span>
              </div>
              {item.badge !== undefined && (
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    isActive ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Storage & System Info Card */}
      <div className="p-6 hidden md:block mt-auto">
        <div className="bg-gray-900 rounded-2xl p-4 text-white text-sm shadow-lg">
          <div className="flex justify-between items-center mb-1">
            <p className="opacity-70 text-xs">Card Database</p>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          </div>
          <div className="w-full bg-gray-700 h-1.5 rounded-full mt-2 overflow-hidden">
            <div className="bg-blue-400 h-1.5 rounded-full w-[65%] transition-all duration-500"></div>
          </div>
          <div className="flex justify-between items-center mt-2">
            <p className="font-mono text-xs opacity-80">{teachersCount + studentsCount} Records</p>
            <span className="text-[10px] text-blue-300 font-medium">Synced</span>
          </div>
        </div>
      </div>
    </aside>
  );
};
