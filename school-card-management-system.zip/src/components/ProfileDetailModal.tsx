import React from 'react';
import { Teacher, Student } from '../types';
import { X, Calendar, Clock, BookOpen, MapPin, Phone, Mail, Award, CheckCircle2 } from 'lucide-react';

interface ProfileDetailModalProps {
  record: Teacher | Student | null;
  onClose: () => void;
}

export const ProfileDetailModal: React.FC<ProfileDetailModalProps> = ({ record, onClose }) => {
  if (!record) return null;

  const isTeacher = 'subject' in record;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 border border-gray-200 shadow-2xl relative my-8 animate-fadeIn">
        {/* Modal Top Banner */}
        <div className="flex items-start justify-between border-b border-gray-100 pb-5 mb-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 sm:w-20 sm:h-20 bg-blue-50 rounded-2xl flex items-center justify-center text-3xl overflow-hidden border border-blue-100 shadow-xs">
              {record.photo ? (
                <img src={record.photo} alt={record.name} className="w-full h-full object-cover" />
              ) : (
                <span>{isTeacher ? '👤' : '👨‍🎓'}</span>
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-2xl font-black text-gray-900">{record.name}</h2>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${
                    record.status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                  }`}
                >
                  {record.status}
                </span>
              </div>
              <p className="text-sm font-semibold text-blue-600 mt-0.5">
                {isTeacher ? (record as Teacher).designation : `Student - Class ${(record as Student).classSection}`}
              </p>
              <p className="text-xs font-mono text-gray-400 mt-0.5">Record ID: {record.id}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-xl transition-all">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="space-y-6 text-sm">
          {/* General Metadata Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-gray-50 p-4 rounded-2xl border border-gray-100">
            {isTeacher ? (
              <>
                <div>
                  <span className="text-[10px] uppercase font-bold text-gray-400 block">Department</span>
                  <span className="font-bold text-gray-800">{(record as Teacher).subject}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-gray-400 block">Experience</span>
                  <span className="font-bold text-gray-800">{(record as Teacher).experience}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-gray-400 block">Class Incharge</span>
                  <span className="font-bold text-gray-800">{(record as Teacher).classIncharge}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-gray-400 block">Joined</span>
                  <span className="font-bold text-gray-800">{(record as Teacher).joiningDate}</span>
                </div>
              </>
            ) : (
              <>
                <div>
                  <span className="text-[10px] uppercase font-bold text-gray-400 block">Roll Number</span>
                  <span className="font-black text-blue-600 text-base">{(record as Student).rollNumber}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-gray-400 block">Father Name</span>
                  <span className="font-bold text-gray-800">{(record as Student).fatherName}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-gray-400 block">Blood Group</span>
                  <span className="font-bold text-rose-600">{(record as Student).bloodGroup}</span>
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-gray-400 block">Attendance</span>
                  <span className="font-bold text-emerald-600">{(record as Student).attendancePercentage}%</span>
                </div>
              </>
            )}
          </div>

          {/* Timetable or Academic Record */}
          {isTeacher ? (
            <div className="space-y-3">
              <h4 className="text-base font-bold text-gray-900 flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-500" /> Weekly Timetable Allocation
              </h4>
              {(record as Teacher).timetable.length > 0 ? (
                <div className="border border-gray-200 rounded-2xl overflow-hidden">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-gray-100 text-gray-600 uppercase font-bold border-b border-gray-200">
                        <th className="p-3">Day</th>
                        <th className="p-3">Period</th>
                        <th className="p-3">Subject</th>
                        <th className="p-3">Class</th>
                        <th className="p-3">Room</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {(record as Teacher).timetable.map((t, idx) => (
                        <tr key={idx} className="hover:bg-blue-50/50">
                          <td className="p-3 font-bold text-gray-900">{t.day}</td>
                          <td className="p-3 font-mono text-gray-600">{t.period}</td>
                          <td className="p-3 font-semibold text-blue-600">{t.subject}</td>
                          <td className="p-3 text-gray-800">{t.classSection}</td>
                          <td className="p-3 text-gray-500">{t.room || 'General Room'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-xs text-gray-400 italic bg-gray-50 p-4 rounded-xl">No specific periods allocated in current timetable.</p>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              <h4 className="text-base font-bold text-gray-900 flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-500" /> Academic & Financial Report
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-blue-50/50 border border-blue-100 p-4 rounded-2xl">
                  <span className="text-[10px] font-bold text-blue-600 uppercase">Term Evaluation</span>
                  <p className="text-lg font-black text-gray-900 mt-1">{(record as Student).resultSummary}</p>
                  <p className="text-xs text-gray-500 mt-1">Mid-term exam performance assessment.</p>
                </div>

                <div className="bg-emerald-50/50 border border-emerald-100 p-4 rounded-2xl">
                  <span className="text-[10px] font-bold text-emerald-600 uppercase">Fee Clearance</span>
                  <p className="text-lg font-black text-gray-900 mt-1 uppercase">{(record as Student).feeStatus}</p>
                  <p className="text-xs text-gray-500 mt-1">Cleared up to {(record as Student).feeMonth}.</p>
                </div>
              </div>
            </div>
          )}

          {/* Contact Details */}
          <div className="border-t border-gray-100 pt-5 flex flex-wrap items-center justify-between gap-4 text-xs text-gray-600">
            {isTeacher ? (
              <>
                <span className="flex items-center gap-1.5 font-medium">
                  <Mail className="w-4 h-4 text-gray-400" /> {(record as Teacher).email}
                </span>
                <span className="flex items-center gap-1.5 font-mono">
                  <Phone className="w-4 h-4 text-gray-400" /> {(record as Teacher).phone || 'N/A'}
                </span>
              </>
            ) : (
              <>
                <span className="flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-gray-400" /> {(record as Student).address}
                </span>
                <span className="flex items-center gap-1.5 font-mono">
                  <Phone className="w-4 h-4 text-gray-400" /> Parent: {(record as Student).parentContact}
                </span>
              </>
            )}
          </div>
        </div>

        {/* Modal Action */}
        <div className="flex justify-end pt-6 border-t border-gray-100 mt-6">
          <button onClick={onClose} className="px-6 py-2.5 bg-gray-900 text-white font-bold rounded-xl hover:bg-black transition-all">
            Close View
          </button>
        </div>
      </div>
    </div>
  );
};
