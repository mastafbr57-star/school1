import React, { useState } from 'react';
import { Student } from '../types';
import { BookOpen, Edit2, Award, FileText, History } from 'lucide-react';

interface ExamsViewProps {
  students: Student[];
  onUpdateStudent: (student: Student) => void;
}

export const ExamsView: React.FC<ExamsViewProps> = ({ students, onUpdateStudent }) => {
  const [selectedClass, setSelectedClass] = useState('8th - A');
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [historyStudent, setHistoryStudent] = useState<Student | null>(null);

  // Extract unique classes
  const classesList = ['Prep', '1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th', '9th', '10th', '11th', '12th'];
  const classes = Array.from(new Set([...classesList, ...students.map(s => s.classSection)])).sort();
  const classStudents = students.filter(s => s.classSection.startsWith(selectedClass) || s.classSection === selectedClass);

  const handleSaveResult = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingStudent) {
      onUpdateStudent(editingStudent);
      setEditingStudent(null);
    }
  };

  return (
    <div className="w-full space-y-6 animate-fadeIn">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Exams & Results</h2>
          <p className="text-xs text-gray-500 mt-1">Manage term examinations and student grading.</p>
        </div>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-xl text-sm font-bold shadow-sm hover:bg-blue-700 flex items-center gap-2">
           <FileText className="w-4 h-4" /> Create Exam
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
         {/* Active Exams list */}
         <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-4">
            <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2"><BookOpen className="w-5 h-5 text-gray-400"/> Ongoing Exams</h3>
            <div className="space-y-3">
               <div className="p-4 border border-blue-100 bg-blue-50/50 rounded-xl">
                  <div className="flex justify-between items-start">
                     <div>
                        <h4 className="font-bold text-blue-900">Mid-Term Examination 2026</h4>
                        <p className="text-xs text-blue-600 mt-1">Classes: All • Ends in 12 days</p>
                     </div>
                     <span className="px-2 py-1 bg-blue-100 text-blue-700 text-[10px] font-bold rounded uppercase">Active</span>
                  </div>
               </div>
               <div className="p-4 border border-gray-200 bg-gray-50 rounded-xl">
                  <div className="flex justify-between items-start">
                     <div>
                        <h4 className="font-bold text-gray-800">Monthly Test - June</h4>
                        <p className="text-xs text-gray-500 mt-1">Classes: 9th, 10th</p>
                     </div>
                     <span className="px-2 py-1 bg-gray-200 text-gray-600 text-[10px] font-bold rounded uppercase">Draft</span>
                  </div>
               </div>
            </div>
         </div>

         {/* Result Entry */}
         <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-4">
            <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2"><Award className="w-5 h-5 text-gray-400"/> Result Entry (Mid-Term)</h3>
            
            <div className="flex gap-2">
               <select 
                 value={selectedClass} 
                 onChange={(e) => setSelectedClass(e.target.value)}
                 className="flex-1 bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 font-bold text-gray-800 outline-none"
               >
                 {classes.map(c => <option key={c} value={c}>{c}</option>)}
               </select>
               <button className="px-4 py-2 bg-gray-900 text-white rounded-lg font-bold text-xs hover:bg-black">Load</button>
            </div>

            <div className="space-y-2 mt-4 max-h-[300px] overflow-y-auto pr-2">
               {classStudents.map(s => (
                  <div key={s.id} className="flex items-center justify-between p-3 border border-gray-100 rounded-lg hover:bg-gray-50">
                     <div>
                        <p className="font-bold text-sm text-gray-900">{s.name}</p>
                        <p className="text-[10px] font-mono text-gray-500">Roll No: {s.rollNumber}</p>
                     </div>
                     <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-emerald-600 mr-2">{s.resultSummary}</span>
                        <button onClick={() => setHistoryStudent(s)} className="p-1.5 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded-md" title="History"><History className="w-3.5 h-3.5"/></button>
                        <button onClick={() => setEditingStudent(s)} className="p-1.5 bg-gray-100 text-gray-600 hover:bg-gray-200 rounded-md" title="Edit"><Edit2 className="w-3.5 h-3.5"/></button>
                        <button className="p-1.5 bg-red-50 text-red-600 hover:bg-red-100 rounded-md" title="PDF"><FileText className="w-3.5 h-3.5"/></button>
                     </div>
                  </div>
               ))}
               {classStudents.length === 0 && <p className="text-xs text-gray-500 text-center py-4">No students.</p>}
            </div>
         </div>
      </div>

      {/* Edit Result Modal */}
      {editingStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Edit Result</h3>
            <p className="text-sm text-gray-500 mb-6">Editing for <span className="font-bold text-gray-800">{editingStudent.name}</span> ({editingStudent.rollNumber})</p>
            
            <form onSubmit={handleSaveResult} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Result Summary</label>
                <input
                  type="text"
                  value={editingStudent.resultSummary}
                  onChange={(e) => setEditingStudent({ ...editingStudent, resultSummary: e.target.value })}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold"
                  placeholder="e.g. A Grade (88%)"
                  required
                />
              </div>

              <div className="flex gap-3 justify-end pt-4">
                <button
                  type="button"
                  onClick={() => setEditingStudent(null)}
                  className="px-4 py-2 font-bold text-gray-600 hover:bg-gray-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* History Modal */}
      {historyStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-gray-900">Exam History</h3>
              <button onClick={() => setHistoryStudent(null)} className="text-gray-400 hover:text-gray-600">✕</button>
            </div>
            <p className="text-sm text-gray-500 mb-6">History for <span className="font-bold text-gray-800">{historyStudent.name}</span> ({historyStudent.rollNumber})</p>
            
            <div className="space-y-4 max-h-[300px] overflow-y-auto">
              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl">
                <div>
                  <p className="font-bold text-gray-900">Mid-Term 2026</p>
                  <p className="text-xs text-gray-500">{historyStudent.resultSummary}</p>
                </div>
                <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-black uppercase rounded">Passed</span>
              </div>
              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl bg-gray-50">
                <div>
                  <p className="font-bold text-gray-900">First Term 2026</p>
                  <p className="text-xs text-gray-500">B Grade (76%)</p>
                </div>
                <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-black uppercase rounded">Passed</span>
              </div>
              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl bg-gray-50">
                <div>
                  <p className="font-bold text-gray-900">Final Term 2025</p>
                  <p className="text-xs text-gray-500">A Grade (84%)</p>
                </div>
                <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-black uppercase rounded">Passed</span>
              </div>
            </div>
            
            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setHistoryStudent(null)}
                className="px-4 py-2 font-bold text-white bg-gray-900 hover:bg-black rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
