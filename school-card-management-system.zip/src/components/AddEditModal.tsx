import React, { useState, useEffect } from 'react';
import { Teacher, Student, RecordType } from '../types';
import { X, Save, Upload, User, School, BookOpen } from 'lucide-react';

interface AddEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveTeacher: (t: Teacher) => void;
  onSaveStudent: (s: Student) => void;
  recordType: RecordType;
  editingRecord: Teacher | Student | null;
}

export const AddEditModal: React.FC<AddEditModalProps> = ({
  isOpen,
  onClose,
  onSaveTeacher,
  onSaveStudent,
  recordType,
  editingRecord,
}) => {
  const isTeacher = recordType === 'teacher';

  // Common fields
  const [id, setId] = useState('');
  const [name, setName] = useState('');
  const [photo, setPhoto] = useState('');
  const [status, setStatus] = useState<'active' | 'inactive'>('active');

  // Teacher specific
  const [subject, setSubject] = useState('');
  const [designation, setDesignation] = useState('Senior Lecturer');
  const [qualification, setQualification] = useState('');
  const [experience, setExperience] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [classIncharge, setClassIncharge] = useState('');

  // Student specific
  const [dob, setDob] = useState('');
  const [fatherName, setFatherName] = useState('');
  const [studentClass, setStudentClass] = useState('8th');
  const [studentSection, setStudentSection] = useState('A');
  const [rollNumber, setRollNumber] = useState('');
  const [address, setAddress] = useState('');
  const [parentContact, setParentContact] = useState('');
  const [emergencyContact, setEmergencyContact] = useState('');
  const [bloodGroup, setBloodGroup] = useState('B+');
  const [feeStatus, setFeeStatus] = useState<'paid' | 'pending' | 'overdue'>('paid');
  const [attendancePercentage, setAttendancePercentage] = useState(95);
  const [resultSummary, setResultSummary] = useState('A Grade (85%)');

  useEffect(() => {
    if (editingRecord) {
      setId(editingRecord.id);
      setName(editingRecord.name);
      setPhoto(editingRecord.photo);
      setStatus(editingRecord.status);

      if ('subject' in editingRecord) {
        setSubject(editingRecord.subject);
        setDesignation(editingRecord.designation);
        setQualification(editingRecord.qualification);
        setExperience(editingRecord.experience);
        setPhone(editingRecord.phone || '');
        setEmail(editingRecord.email);
        setClassIncharge(editingRecord.classIncharge);
      } else {
        setDob(editingRecord.dob);
        setFatherName(editingRecord.fatherName);
        const parts = editingRecord.classSection.split(' - ');
        setStudentClass(parts[0] || '8th');
        setStudentSection(parts[1] || '');
        setRollNumber(editingRecord.rollNumber);
        setAddress(editingRecord.address);
        setParentContact(editingRecord.parentContact);
        setEmergencyContact(editingRecord.emergencyContact);
        setBloodGroup(editingRecord.bloodGroup);
        setFeeStatus(editingRecord.feeStatus);
        setAttendancePercentage(editingRecord.attendancePercentage);
        setResultSummary(editingRecord.resultSummary);
      }
    } else {
      // Defaults for new record
      const randomNum = Math.floor(100 + Math.random() * 900);
      if (isTeacher) {
        setId(`T-${randomNum}`);
        setName('');
        setPhoto('');
        setSubject('Mathematics');
        setDesignation('Lecturer');
        setQualification('M.Sc');
        setExperience('3 Years');
        setPhone('+92 300 0000000');
        setEmail('teacher@metropolitan.edu.pk');
        setClassIncharge('Grade 8 - A');
      } else {
        setId(`S-${Math.floor(1000 + Math.random() * 9000)}`);
        setName('');
        setPhoto('');
        setDob('2012-05-15');
        setFatherName('');
        setStudentClass('8th');
        setStudentSection('A');
        setRollNumber(`${Math.floor(1 + Math.random() * 30)}`);
        setAddress('House 10, Street 5, Islamabad');
        setParentContact('+92 333 0000000');
        setEmergencyContact('+92 333 0000000');
        setBloodGroup('B+');
        setFeeStatus('paid');
        setAttendancePercentage(92);
        setResultSummary('A Grade (85%)');
      }
    }
  }, [editingRecord, isTeacher, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isTeacher) {
      const newTeacher: Teacher = {
        id: id || `T-${Math.floor(100 + Math.random() * 900)}`,
        name: name || 'Unnamed Teacher',
        photo,
        subject: subject || 'General',
        designation,
        qualification: qualification || 'B.Ed',
        experience: experience || '1 Year',
        phone,
        email: email || 'info@school.edu',
        classIncharge: classIncharge || 'None',
        joiningDate: new Date().toISOString().split('T')[0],
        status,
        timetable: (editingRecord && 'timetable' in editingRecord ? editingRecord.timetable : []) || [],
      };
      onSaveTeacher(newTeacher);
    } else {
      const newStudent: Student = {
        id: id || `S-${Math.floor(1000 + Math.random() * 9000)}`,
        name: name || 'Unnamed Student',
        photo,
        dob: dob || '2012-01-01',
        fatherName: fatherName || 'Parent Name',
        classSection: studentSection ? `${studentClass} - ${studentSection}` : studentClass,
        rollNumber: rollNumber || '01',
        address: address || 'City Address',
        parentContact: parentContact || '+92 300',
        emergencyContact: emergencyContact || parentContact || '+92 300',
        bloodGroup,
        feeStatus,
        feeMonth: 'June 2026',
        attendancePercentage: Number(attendancePercentage) || 90,
        resultSummary,
        status,
      };
      onSaveStudent(newStudent);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 border border-gray-200 shadow-2xl relative my-8 animate-fadeIn">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-gray-100 pb-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center font-bold text-xl">
              {isTeacher ? '👨‍🏫' : '👨‍🎓'}
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">
                {editingRecord ? `Edit ${isTeacher ? 'Teacher' : 'Student'} Profile` : `Add New ${isTeacher ? 'Teacher' : 'Student'}`}
              </h3>
              <p className="text-xs text-gray-400">Fill in the details below to update the school database.</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-xl transition-all">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-sm">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Full Name *</label>
              <input
                required
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={isTeacher ? 'e.g. Muhammad Ali' : 'e.g. Ahmad Khan'}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-medium text-gray-900 focus:bg-white focus:border-blue-500 outline-none transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Record ID *</label>
              <input
                required
                type="text"
                value={id}
                onChange={(e) => setId(e.target.value)}
                placeholder={isTeacher ? 'T-001' : 'S-1023'}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-mono font-bold text-gray-900 focus:bg-white focus:border-blue-500 outline-none transition-all"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Photo Image (URL or Upload)</label>
              <div className="flex gap-2 items-center">
                <input
                  type="text"
                  value={photo}
                  onChange={(e) => setPhoto(e.target.value)}
                  placeholder="https://images.unsplash.com/... or upload"
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 font-mono text-xs text-gray-600 focus:bg-white focus:border-blue-500 outline-none transition-all"
                />
                <label className="cursor-pointer shrink-0 bg-gray-100 hover:bg-gray-200 px-3 py-2 rounded-xl text-xs font-bold text-gray-700 border border-gray-200 transition-colors">
                  Upload Image
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        const reader = new FileReader();
                        reader.onloadend = () => {
                          setPhoto(reader.result as string);
                        };
                        reader.readAsDataURL(file);
                      }
                    }}
                  />
                </label>
                {photo && (
                  <div className="w-9 h-9 rounded-full bg-gray-200 overflow-hidden shrink-0 border border-gray-300">
                    <img src={photo} alt="Preview" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>
            </div>

            {isTeacher ? (
              <>
                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Subject *</label>
                  <input
                    required
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="Mathematics, Physics, etc."
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Designation</label>
                  <input
                    type="text"
                    value={designation}
                    onChange={(e) => setDesignation(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Qualification</label>
                  <input
                    type="text"
                    value={qualification}
                    onChange={(e) => setQualification(e.target.value)}
                    placeholder="M.Phil Math, B.Ed"
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Experience</label>
                  <input
                    type="text"
                    value={experience}
                    onChange={(e) => setExperience(e.target.value)}
                    placeholder="8 Years"
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Class In-Charge</label>
                  <input
                    type="text"
                    value={classIncharge}
                    onChange={(e) => setClassIncharge(e.target.value)}
                    placeholder="Grade 10 - Sci"
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-medium"
                  />
                </div>
              </>
            ) : (
              <>
                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Father&apos;s Name *</label>
                  <input
                    required
                    type="text"
                    value={fatherName}
                    onChange={(e) => setFatherName(e.target.value)}
                    placeholder="Sardar Kamran Khan"
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-medium"
                  />
                </div>

                <div className="sm:col-span-2 grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Class *</label>
                    <select
                      required
                      value={studentClass}
                      onChange={(e) => setStudentClass(e.target.value)}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold"
                    >
                      {['Prep', '1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th', '9th', '10th', '11th', '12th'].map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Section (Editable) *</label>
                    <input
                      required
                      type="text"
                      value={studentSection}
                      onChange={(e) => setStudentSection(e.target.value)}
                      placeholder="e.g. A"
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-medium"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Roll Number *</label>
                  <input
                    required
                    type="text"
                    value={rollNumber}
                    onChange={(e) => setRollNumber(e.target.value)}
                    placeholder="12"
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Date of Birth</label>
                  <input
                    type="date"
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Parent Contact</label>
                  <input
                    type="text"
                    value={parentContact}
                    onChange={(e) => setParentContact(e.target.value)}
                    placeholder="+92 333 1234567"
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Blood Group</label>
                  <select
                    value={bloodGroup}
                    onChange={(e) => setBloodGroup(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold"
                  >
                    {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((bg) => (
                      <option key={bg} value={bg}>
                        {bg}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Home Address</label>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="House 45, Street 12, Islamabad"
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-medium"
                  />
                </div>
              </>
            )}

            <div>
              <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold"
              >
                <option value="active">🟢 Active</option>
                <option value="inactive">🔴 Inactive</option>
              </select>
            </div>
            {recordType === 'student' && (
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Attendance %</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={attendancePercentage}
                  onChange={(e) => setAttendancePercentage(Number(e.target.value))}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-medium"
                />
              </div>
            )}
          </div>

          {/* Footer Actions */}
          <div className="flex items-center justify-end gap-3 pt-6 border-t border-gray-100 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 text-gray-600 font-bold hover:bg-gray-100 rounded-xl transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save Record</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
