import React from 'react';
import { Search, Plus, Printer, Download, Filter } from 'lucide-react';
import { RecordType } from '../types';

interface HeaderProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  onOpenAddModal: () => void;
  onOpenPrintBatch: () => void;
  onExportExcel: () => void;
  recordType: RecordType;
  setRecordType: (type: RecordType) => void;
  classFilter: string;
  setClassFilter: (cls: string) => void;
  availableClasses: string[];
}

export const Header: React.FC<HeaderProps> = ({
  searchTerm,
  setSearchTerm,
  onOpenAddModal,
  onOpenPrintBatch,
  onExportExcel,
  recordType,
  setRecordType,
  classFilter,
  setClassFilter,
  availableClasses,
}) => {
  return (
    <header className="min-h-20 bg-white border-b border-gray-200 px-4 md:px-8 py-3 flex flex-wrap items-center justify-between gap-4 sticky top-0 z-20 shadow-xs print:hidden">
      {/* Search Input */}
      <div className="flex items-center bg-gray-100 rounded-xl px-4 py-2.5 w-full max-w-md border border-transparent focus-within:border-blue-400 focus-within:bg-white focus-within:ring-2 focus-within:ring-blue-100 transition-all">
        <Search className="w-4 h-4 text-gray-400 flex-shrink-0" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="🔍 Search Teachers, Students, Name, or ID (e.g. T-001)..."
          className="bg-transparent border-none outline-none ml-3 text-sm w-full text-gray-800 placeholder-gray-400 font-medium"
        />
        {searchTerm && (
          <button
            onClick={() => setSearchTerm('')}
            className="text-xs text-gray-400 hover:text-gray-600 px-1.5 py-0.5 bg-gray-200 rounded-md ml-1"
          >
            Clear
          </button>
        )}
      </div>

      {/* Filters & Actions */}
      <div className="flex flex-wrap items-center gap-3 ml-auto">
        {/* Class Filter Dropdown */}
        <div className="flex items-center bg-gray-50 border border-gray-200 rounded-xl px-3 py-1.5 text-xs font-medium text-gray-700">
          <Filter className="w-3.5 h-3.5 mr-1.5 text-gray-400" />
          <select
            value={classFilter}
            onChange={(e) => setClassFilter(e.target.value)}
            className="bg-transparent border-none outline-none font-semibold text-gray-800 cursor-pointer pr-2"
          >
            <option value="all">🏷️ All Classes / Depts</option>
            {availableClasses.map((cls) => (
              <option key={cls} value={cls}>
                {cls}
              </option>
            ))}
          </select>
        </div>

        {/* Quick Batch Tools */}
        <button
          onClick={onExportExcel}
          title="Export records to CSV/Excel format"
          className="p-2.5 text-gray-600 bg-gray-50 border border-gray-200 hover:bg-gray-100 rounded-xl transition-all flex items-center gap-1.5 text-xs font-semibold"
        >
          <Download className="w-4 h-4 text-gray-600" />
          <span className="hidden sm:inline">Export</span>
        </button>

        <button
          onClick={onOpenPrintBatch}
          title="Print all filtered cards"
          className="p-2.5 text-blue-700 bg-blue-50 border border-blue-100 hover:bg-blue-100 rounded-xl transition-all flex items-center gap-1.5 text-xs font-semibold"
        >
          <Printer className="w-4 h-4 text-blue-600" />
          <span className="hidden sm:inline">Print ID Cards</span>
        </button>

        {/* Add Record Primary Button */}
        <button
          onClick={onOpenAddModal}
          className="px-4 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 shadow-sm shadow-blue-600/20 active:scale-95 transition-all flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Add {recordType === 'teacher' ? 'Teacher' : 'Student'}</span>
        </button>
      </div>
    </header>
  );
};
