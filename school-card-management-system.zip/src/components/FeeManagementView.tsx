import React, { useState } from 'react';
import { Student } from '../types';
import { DollarSign, Search, CheckCircle, AlertCircle, Clock } from 'lucide-react';

interface FeeManagementViewProps {
  students: Student[];
  onUpdateStudent: (student: Student) => void;
  schoolName?: string;
}

export const FeeManagementView: React.FC<FeeManagementViewProps> = ({ students, onUpdateStudent, schoolName = 'EduCard Academy' }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [printingStudent, setPrintingStudent] = useState<Student | null>(null);
  const [historyStudent, setHistoryStudent] = useState<Student | null>(null);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingStudent) {
      onUpdateStudent(editingStudent);
      setEditingStudent(null);
    }
  };

  const handlePrint = (student: Student) => {
    setPrintingStudent(student);
    setTimeout(() => {
      window.print();
    }, 100);
  };

  const filteredStudents = students.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    s.rollNumber.includes(searchTerm)
  );

  return (
    <div className="w-full space-y-6 animate-fadeIn">
      <div className="flex items-center justify-between print:hidden">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Fee Management</h2>
          <p className="text-xs text-gray-500 mt-1">Track student fee statuses and generate vouchers.</p>
        </div>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-3 gap-4 print:hidden">
        <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl flex items-center gap-3">
          <div className="p-2 bg-emerald-100 rounded-lg text-emerald-600"><CheckCircle className="w-6 h-6"/></div>
          <div>
             <p className="text-[10px] font-bold text-emerald-700 uppercase">Paid</p>
             <p className="text-xl font-black text-emerald-900">{students.filter(s => s.feeStatus === 'paid').length}</p>
          </div>
        </div>
        <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl flex items-center gap-3">
          <div className="p-2 bg-amber-100 rounded-lg text-amber-600"><Clock className="w-6 h-6"/></div>
          <div>
             <p className="text-[10px] font-bold text-amber-700 uppercase">Pending</p>
             <p className="text-xl font-black text-amber-900">{students.filter(s => s.feeStatus === 'pending').length}</p>
          </div>
        </div>
        <div className="bg-rose-50 border border-rose-200 p-4 rounded-xl flex items-center gap-3">
          <div className="p-2 bg-rose-100 rounded-lg text-rose-600"><AlertCircle className="w-6 h-6"/></div>
          <div>
             <p className="text-[10px] font-bold text-rose-700 uppercase">Overdue</p>
             <p className="text-xl font-black text-rose-900">{students.filter(s => s.feeStatus === 'overdue').length}</p>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-6 print:hidden">
        <div className="flex items-center bg-gray-50 rounded-xl px-4 py-2 w-full max-w-md border border-gray-200 focus-within:border-blue-400 transition-all">
          <Search className="w-4 h-4 text-gray-400 flex-shrink-0" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search student to collect fee..."
            className="bg-transparent border-none outline-none ml-3 text-sm w-full text-gray-800 font-medium"
          />
        </div>

        <div className="border border-gray-200 rounded-xl overflow-hidden">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="p-3 font-bold text-gray-600">ID / Roll No</th>
                <th className="p-3 font-bold text-gray-600">Student Name</th>
                <th className="p-3 font-bold text-gray-600">Class</th>
                <th className="p-3 font-bold text-gray-600">Total Fee</th>
                <th className="p-3 font-bold text-gray-600">Paid</th>
                <th className="p-3 font-bold text-gray-600">Remaining</th>
                <th className="p-3 font-bold text-gray-600">Fee Status</th>
                <th className="p-3 font-bold text-gray-600 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredStudents.map((s) => {
                const total = s.feeAmount || 0;
                const paid = s.feePaidAmount || 0;
                const remaining = total - paid;
                return (
                <tr key={s.id} className="hover:bg-gray-50">
                  <td className="p-3 font-mono font-bold text-gray-600">{s.id} / {s.rollNumber}</td>
                  <td className="p-3 font-bold text-gray-900">{s.name}</td>
                  <td className="p-3 text-gray-600 font-medium">{s.classSection}</td>
                  <td className="p-3 font-bold text-gray-800">Rs. {total}</td>
                  <td className="p-3 font-bold text-emerald-600">Rs. {paid}</td>
                  <td className="p-3 font-bold text-rose-600">Rs. {remaining}</td>
                  <td className="p-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                      s.feeStatus === 'paid' ? 'bg-emerald-100 text-emerald-700 border border-emerald-200' :
                      s.feeStatus === 'pending' ? 'bg-amber-100 text-amber-700 border border-amber-200' :
                      'bg-rose-100 text-rose-700 border border-rose-200'
                    }`}>
                      {s.feeStatus}
                    </span>
                  </td>
                  <td className="p-3 text-right">
                    <button 
                      onClick={() => setEditingStudent(s)}
                      className="px-3 py-1.5 bg-gray-100 text-gray-700 rounded text-xs font-bold hover:bg-gray-200 mr-2"
                    >
                      Edit
                    </button>
                    <button 
                      onClick={() => handlePrint(s)}
                      className="px-3 py-1.5 bg-red-50 text-red-600 rounded text-xs font-bold hover:bg-red-100 mr-2"
                    >
                      PDF
                    </button>
                    <button 
                      onClick={() => setHistoryStudent(s)}
                      className="px-3 py-1.5 bg-blue-50 text-blue-600 rounded text-xs font-bold hover:bg-blue-100 mr-2"
                    >
                      History
                    </button>
                    <button 
                      onClick={() => setEditingStudent(s)}
                      className="px-3 py-1.5 bg-gray-900 text-white rounded text-xs font-bold hover:bg-black"
                    >
                      Collect
                    </button>
                  </td>
                </tr>
              )})}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Fee Modal */}
      {editingStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Edit Fee Details</h3>
            <p className="text-sm text-gray-500 mb-6">Editing for <span className="font-bold text-gray-800">{editingStudent.name}</span> ({editingStudent.rollNumber})</p>
            
            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Total Fee Amount (Rs.)</label>
                <input
                  type="number"
                  value={editingStudent.feeAmount || 0}
                  onChange={(e) => setEditingStudent({ ...editingStudent, feeAmount: Number(e.target.value) })}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Paid Amount (Rs.)</label>
                <input
                  type="number"
                  value={editingStudent.feePaidAmount || 0}
                  onChange={(e) => setEditingStudent({ ...editingStudent, feePaidAmount: Number(e.target.value) })}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Fee Status</label>
                <select
                  value={editingStudent.feeStatus}
                  onChange={(e) => setEditingStudent({ ...editingStudent, feeStatus: e.target.value as any })}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 font-bold"
                >
                  <option value="paid">🟢 Paid</option>
                  <option value="pending">🟡 Pending</option>
                  <option value="overdue">🔴 Overdue</option>
                </select>
              </div>

              <div className="flex gap-3 justify-end pt-4">
                <button
                  type="button"
                  onClick={() => setEditingStudent(null)}
                  className="px-4 py-2 font-bold text-gray-600 hover:bg-gray-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* History Modal */}
      {historyStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-gray-900">Fee History</h3>
              <button onClick={() => setHistoryStudent(null)} className="text-gray-400 hover:text-gray-600">✕</button>
            </div>
            <p className="text-sm text-gray-500 mb-6">History for <span className="font-bold text-gray-800">{historyStudent.name}</span> ({historyStudent.rollNumber})</p>
            
            <div className="space-y-4 max-h-[300px] overflow-y-auto">
              {/* Mock History Items */}
              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl">
                <div>
                  <p className="font-bold text-gray-900">{historyStudent.feeMonth}</p>
                  <p className="text-xs text-gray-500">Paid Amount: Rs. {historyStudent.feePaidAmount || 0} / {historyStudent.feeAmount || 0}</p>
                </div>
                <span className={`px-2 py-1 rounded text-[10px] font-black uppercase ${
                    historyStudent.feeStatus === 'paid' ? 'bg-emerald-100 text-emerald-700 border border-emerald-200' :
                    historyStudent.feeStatus === 'pending' ? 'bg-amber-100 text-amber-700 border border-amber-200' :
                    'bg-rose-100 text-rose-700 border border-rose-200'
                  }`}>
                    {historyStudent.feeStatus}
                </span>
              </div>
              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl bg-gray-50">
                <div>
                  <p className="font-bold text-gray-900">May 2026</p>
                  <p className="text-xs text-gray-500">Paid Amount: Rs. 3500 / 3500</p>
                </div>
                <span className="px-2 py-1 rounded text-[10px] font-black uppercase bg-emerald-100 text-emerald-700 border border-emerald-200">
                    Paid
                </span>
              </div>
              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl bg-gray-50">
                <div>
                  <p className="font-bold text-gray-900">April 2026</p>
                  <p className="text-xs text-gray-500">Paid Amount: Rs. 3500 / 3500</p>
                </div>
                <span className="px-2 py-1 rounded text-[10px] font-black uppercase bg-emerald-100 text-emerald-700 border border-emerald-200">
                    Paid
                </span>
              </div>
            </div>
            
            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setHistoryStudent(null)}
                className="px-4 py-2 font-bold text-white bg-gray-900 hover:bg-black rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Print Voucher Hidden Container */}
      <div className="hidden print:block absolute inset-0 bg-white z-[100] p-8">
        {printingStudent && (
          <div className="max-w-2xl mx-auto border-2 border-gray-800 p-8">
            <div className="text-center border-b-2 border-gray-800 pb-6 mb-6">
              <h1 className="text-3xl font-black text-gray-900 uppercase tracking-widest">{schoolName}</h1>
              <p className="text-sm font-bold text-gray-600 mt-2">FEE VOUCHER / RECEIPT</p>
            </div>
            
            <div className="grid grid-cols-2 gap-8 mb-8">
              <div>
                <p className="text-xs text-gray-500 font-bold uppercase mb-1">Student Name</p>
                <p className="text-lg font-bold text-gray-900">{printingStudent.name}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 font-bold uppercase mb-1">Roll Number</p>
                <p className="text-lg font-bold text-gray-900">{printingStudent.rollNumber}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 font-bold uppercase mb-1">Class & Section</p>
                <p className="text-lg font-bold text-gray-900">{printingStudent.classSection}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 font-bold uppercase mb-1">Fee Month</p>
                <p className="text-lg font-bold text-gray-900">{printingStudent.feeMonth}</p>
              </div>
            </div>

            <table className="w-full mb-8 border-collapse">
              <thead>
                <tr className="border-b-2 border-gray-800">
                  <th className="text-left py-2 text-sm font-bold uppercase">Description</th>
                  <th className="text-right py-2 text-sm font-bold uppercase">Amount</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-300">
                  <td className="py-4 text-gray-800 font-medium">Monthly Tuition Fee</td>
                  <td className="py-4 text-right font-bold text-gray-900">Rs. {printingStudent.feeAmount || 0}</td>
                </tr>
              </tbody>
              <tfoot>
                <tr>
                  <td className="py-4 text-right font-bold uppercase text-gray-600">Total Payable</td>
                  <td className="py-4 text-right font-black text-xl text-gray-900">Rs. {printingStudent.feeAmount || 0}</td>
                </tr>
                <tr>
                  <td className="py-2 text-right font-bold uppercase text-gray-600">Status</td>
                  <td className={`py-2 text-right font-black uppercase ${printingStudent.feeStatus === 'paid' ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {printingStudent.feeStatus}
                  </td>
                </tr>
              </tfoot>
            </table>

            <div className="flex justify-between mt-16 pt-8 border-t border-gray-300">
              <div className="text-center">
                <div className="w-48 border-b border-gray-800 mb-2"></div>
                <p className="text-xs font-bold text-gray-500 uppercase">Cashier Signature</p>
              </div>
              <div className="text-center">
                <div className="w-48 border-b border-gray-800 mb-2"></div>
                <p className="text-xs font-bold text-gray-500 uppercase">Parent Signature</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
