import React, { useState } from 'react';
import { Teacher } from '../types';
import { Calendar, Clock, Edit2, Eye, Mail, Phone, BookOpen, Award, Briefcase, School, History } from 'lucide-react';

interface TeacherCardProps {
  teacher: Teacher;
  onViewProfile: (teacher: Teacher) => void;
  onEdit: (teacher: Teacher) => void;
  onSelectForId: (teacher: Teacher) => void;
  isSelectedForId: boolean;
}

export const TeacherCard: React.FC<TeacherCardProps> = ({
  teacher,
  onViewProfile,
  onEdit,
  onSelectForId,
  isSelectedForId,
}) => {
  const [showHistory, setShowHistory] = useState(false);

  return (
    <div
      className={`bg-white p-5 rounded-2xl border transition-all duration-200 flex flex-col sm:flex-row items-start gap-5 shadow-xs hover:shadow-md relative ${
        isSelectedForId ? 'border-blue-500 ring-2 ring-blue-500/20 bg-blue-50/20' : 'border-gray-200 hover:border-gray-300'
      }`}
    >
      {/* Teacher Photo */}
      <div className="w-24 h-24 sm:w-28 sm:h-28 bg-blue-100 rounded-xl flex-shrink-0 flex items-center justify-center text-4xl overflow-hidden relative border border-blue-200/60 shadow-inner group">
        {teacher.photo ? (
          <img
            src={teacher.photo}
            alt={teacher.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            referrerPolicy="no-referrer"
          />
        ) : (
          <span className="text-4xl">👤</span>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-1.5 justify-center">
          <span className="text-[9px] text-white font-bold uppercase tracking-wider">Teacher</span>
        </div>
      </div>

      {/* Details Grid */}
      <div className="flex-1 w-full grid grid-cols-1 sm:grid-cols-2 gap-y-2.5 gap-x-4 text-sm">
        {/* Name & ID Header */}
        <div className="col-span-1 sm:col-span-2 flex flex-wrap justify-between items-start border-b border-gray-100 pb-2 gap-2">
          <div>
            <h3 className="text-lg font-bold text-gray-900 flex items-center flex-wrap gap-2">
              {teacher.name}
              <span
                className={`px-2 py-0.5 rounded text-[10px] uppercase font-black tracking-wider ${
                  teacher.status === 'active'
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                    : 'bg-rose-100 text-rose-800 border border-rose-200'
                }`}
              >
                {teacher.status === 'active' ? '🟢 Active' : '🔴 Inactive'}
              </span>
            </h3>
            <p className="text-xs text-blue-600 font-medium">{teacher.designation}</p>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-xs font-mono font-bold text-gray-700 bg-gray-100 px-2 py-1 rounded-md border border-gray-200">
              ID: {teacher.id}
            </span>
            <span className="text-[10px] text-gray-400 mt-0.5 font-medium">Joined {teacher.joiningDate}</span>
          </div>
        </div>

        {/* Info Rows */}
        <div>
          <span className="text-gray-400 block text-[10px] uppercase font-bold tracking-wider flex items-center gap-1">
            <BookOpen className="w-3 h-3 text-blue-500" /> Subject
          </span>
          <span className="font-semibold text-gray-800">{teacher.subject}</span>
        </div>

        <div>
          <span className="text-gray-400 block text-[10px] uppercase font-bold tracking-wider flex items-center gap-1">
            <Award className="w-3 h-3 text-purple-500" /> Qualification
          </span>
          <span className="font-semibold text-gray-800">{teacher.qualification}</span>
        </div>

        <div>
          <span className="text-gray-400 block text-[10px] uppercase font-bold tracking-wider flex items-center gap-1">
            <Briefcase className="w-3 h-3 text-amber-500" /> Experience
          </span>
          <span className="font-semibold text-gray-800">{teacher.experience}</span>
        </div>

        <div>
          <span className="text-gray-400 block text-[10px] uppercase font-bold tracking-wider flex items-center gap-1">
            <School className="w-3 h-3 text-emerald-500" /> Class In-charge
          </span>
          <span className="font-semibold text-gray-800">{teacher.classIncharge}</span>
        </div>

        {/* Contact Info (if available) */}
        <div className="col-span-1 sm:col-span-2 pt-1 flex flex-wrap items-center gap-4 text-xs text-gray-500 font-medium border-t border-gray-50">
          <span className="flex items-center gap-1.5 truncate max-w-xs">
            <Mail className="w-3.5 h-3.5 text-gray-400" /> {teacher.email}
          </span>
          {teacher.phone && (
            <span className="flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-gray-400" /> {teacher.phone}
            </span>
          )}
          <span className="flex items-center gap-1 ml-auto text-blue-600 bg-blue-50 px-2 py-0.5 rounded text-[11px] font-semibold">
            <Clock className="w-3 h-3" /> {teacher.timetable.length} Periods/Wk
          </span>
        </div>

        {/* Action Footer */}
        <div className="col-span-1 sm:col-span-2 pt-3 flex flex-wrap gap-2 items-center justify-end border-t border-gray-100">
          <button
            onClick={() => onSelectForId(teacher)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
              isSelectedForId
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <span>🪪</span> {isSelectedForId ? 'Selected for ID Preview' : 'Select for ID'}
          </button>

          <button
            onClick={() => setShowHistory(true)}
            className="px-3 py-1.5 border border-gray-200 rounded-xl text-xs font-bold text-blue-600 hover:bg-blue-50 hover:border-blue-300 transition-all flex items-center gap-1"
          >
            <History className="w-3.5 h-3.5" />
            <span>History</span>
          </button>

          <button
            onClick={() => onEdit(teacher)}
            className="px-3 py-1.5 border border-gray-200 rounded-xl text-xs font-bold text-gray-700 hover:bg-gray-50 hover:border-gray-300 transition-all flex items-center gap-1"
          >
            <Edit2 className="w-3.5 h-3.5 text-gray-500" />
            <span>Edit</span>
          </button>

          <button
            onClick={() => onViewProfile(teacher)}
            className="px-3.5 py-1.5 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-xl text-xs font-bold transition-all flex items-center gap-1"
          >
            <Eye className="w-3.5 h-3.5 text-blue-600" />
            <span>View Profile & Timetable</span>
          </button>
        </div>
      </div>

      {/* History Modal */}
      {showHistory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-gray-900">Teacher Employment History</h3>
              <button onClick={() => setShowHistory(false)} className="text-gray-400 hover:text-gray-600">✕</button>
            </div>
            <p className="text-sm text-gray-500 mb-6">Record for <span className="font-bold text-gray-800">{teacher.name}</span> ({teacher.id})</p>
            
            <div className="space-y-4 max-h-[300px] overflow-y-auto">
              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl">
                <div>
                  <p className="font-bold text-gray-900">Annual Appraisal 2026</p>
                  <p className="text-xs text-gray-500">Performance: Excellent</p>
                </div>
                <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-black uppercase rounded">Top Rated</span>
              </div>
              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl bg-gray-50">
                <div>
                  <p className="font-bold text-gray-900">Joined Faculty</p>
                  <p className="text-xs text-gray-500">{teacher.joiningDate}</p>
                </div>
                <span className="px-2 py-1 bg-gray-200 text-gray-700 text-[10px] font-black uppercase rounded">Completed</span>
              </div>
            </div>
            
            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowHistory(false)}
                className="px-4 py-2 font-bold text-white bg-gray-900 hover:bg-black rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
