import React from 'react';
import { Teacher, Student } from '../types';
import { Users, GraduationCap, CheckCircle, AlertCircle, Clock, BookOpen, TrendingUp, DollarSign } from 'lucide-react';

interface StatsOverviewProps {
  teachers: Teacher[];
  students: Student[];
}

export const StatsOverview: React.FC<StatsOverviewProps> = ({ teachers, students }) => {
  const activeTeachers = teachers.filter((t) => t.status === 'active').length;
  const activeStudents = students.filter((s) => s.status === 'active').length;

  const paidStudents = students.filter((s) => s.feeStatus === 'paid').length;
  const pendingStudents = students.filter((s) => s.feeStatus === 'pending').length;
  const overdueStudents = students.filter((s) => s.feeStatus === 'overdue').length;

  const avgAttendance =
    students.length > 0
      ? Math.round(students.reduce((acc, s) => acc + s.attendancePercentage, 0) / students.length)
      : 0;

  // Group students by class
  const classBreakdown = students.reduce((acc, s) => {
    acc[s.classSection] = (acc[s.classSection] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">📊 School Analytics & Reports</h2>
          <p className="text-xs text-gray-500 mt-1">Real-time attendance summaries, financial fee indicators, and faculty stats.</p>
        </div>
        <span className="px-3 py-1 bg-emerald-100 text-emerald-800 rounded-full text-xs font-bold flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-600"></span> Academic Term 2026
        </span>
      </div>

      {/* Top Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase">Total Faculty</p>
            <h4 className="text-2xl font-black text-gray-900">{teachers.length}</h4>
            <p className="text-[10px] text-emerald-600 font-bold">{activeTeachers} Active Teachers</p>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase">Enrolled Students</p>
            <h4 className="text-2xl font-black text-gray-900">{students.length}</h4>
            <p className="text-[10px] text-blue-600 font-bold">{activeStudents} Active Students</p>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase">Avg Attendance</p>
            <h4 className="text-2xl font-black text-gray-900">{avgAttendance}%</h4>
            <p className="text-[10px] text-purple-600 font-bold">School-wide target 90%</p>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-white p-5 rounded-2xl border border-gray-200 shadow-xs flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <DollarSign className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase">Fee Recovery</p>
            <h4 className="text-2xl font-black text-gray-900">
              {students.length > 0 ? Math.round((paidStudents / students.length) * 100) : 0}%
            </h4>
            <p className="text-[10px] text-amber-700 font-bold">{paidStudents} of {students.length} Paid</p>
          </div>
        </div>
      </div>

      {/* Detailed Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Fee Breakdown Card */}
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-xs space-y-4">
          <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
            <span>💰</span> Student Fee Status Summary
          </h3>
          <div className="grid grid-cols-3 gap-3 pt-2">
            <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl text-center">
              <CheckCircle className="w-6 h-6 text-emerald-600 mx-auto mb-1" />
              <span className="text-xl font-black text-emerald-900 block">{paidStudents}</span>
              <span className="text-[11px] font-bold text-emerald-700 uppercase">Paid Fee</span>
            </div>

            <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl text-center">
              <Clock className="w-6 h-6 text-amber-600 mx-auto mb-1" />
              <span className="text-xl font-black text-amber-900 block">{pendingStudents}</span>
              <span className="text-[11px] font-bold text-amber-700 uppercase">Pending</span>
            </div>

            <div className="bg-rose-50 border border-rose-200 p-4 rounded-xl text-center">
              <AlertCircle className="w-6 h-6 text-rose-600 mx-auto mb-1" />
              <span className="text-xl font-black text-rose-900 block">{overdueStudents}</span>
              <span className="text-[11px] font-bold text-rose-700 uppercase">Overdue</span>
            </div>
          </div>

          <div className="pt-2">
            <p className="text-xs text-gray-500 font-medium">Financial health indicator based on June 2026 fee cycle.</p>
          </div>
        </div>

        {/* Class Enrollment Breakdown */}
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-xs space-y-4">
          <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
            <span>📚</span> Enrollment by Class & Section
          </h3>
          <div className="space-y-3 pt-1">
            {Object.entries(classBreakdown).map(([cls, cnt]) => {
              const pct = Math.round((cnt / students.length) * 100);
              return (
                <div key={cls} className="space-y-1">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-gray-800">{cls}</span>
                    <span className="text-gray-500">{cnt} Students ({pct}%)</span>
                  </div>
                  <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${pct}%` }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
