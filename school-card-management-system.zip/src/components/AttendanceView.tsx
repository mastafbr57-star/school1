import React, { useState } from 'react';
import { Student } from '../types';
import { Calendar, Search, CheckCircle2, XCircle, History } from 'lucide-react';

interface AttendanceViewProps {
  students: Student[];
}

export const AttendanceView: React.FC<AttendanceViewProps> = ({ students }) => {
  const [selectedClass, setSelectedClass] = useState('8th - A');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  
  // Local state to simulate attendance marking
  const [attendanceRecords, setAttendanceRecords] = useState<Record<string, 'Present' | 'Absent' | 'Leave'>>({});
  const [historyStudent, setHistoryStudent] = useState<Student | null>(null);

  // Extract unique classes
  const classesList = ['Prep', '1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th', '9th', '10th', '11th', '12th'];
  const classes = Array.from(new Set([...classesList, ...students.map(s => s.classSection)])).sort();

  const classStudents = students.filter(s => s.classSection.startsWith(selectedClass) || s.classSection === selectedClass);

  const handleMark = (studentId: string, status: 'Present' | 'Absent' | 'Leave') => {
    setAttendanceRecords(prev => ({
      ...prev,
      [studentId]: status
    }));
  };

  return (
    <div className="w-full space-y-6 animate-fadeIn">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Daily Attendance</h2>
          <p className="text-xs text-gray-500 mt-1">Mark and monitor student attendance.</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm space-y-6">
        {/* Controls */}
        <div className="flex flex-wrap gap-4">
          <div className="flex-1 min-w-[200px]">
            <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Select Class</label>
            <select 
              value={selectedClass} 
              onChange={(e) => setSelectedClass(e.target.value)}
              className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 font-bold text-gray-800 outline-none focus:border-blue-500"
            >
              {classes.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div className="flex-1 min-w-[200px]">
            <label className="block text-xs font-bold text-gray-700 uppercase tracking-wider mb-1">Date</label>
            <input 
              type="date" 
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 font-bold text-gray-800 outline-none focus:border-blue-500"
            />
          </div>
          <div className="flex items-end">
             <button className="px-6 py-2.5 bg-blue-600 text-white rounded-xl font-bold shadow-sm hover:bg-blue-700 flex items-center gap-2">
                <Calendar className="w-4 h-4" /> Load Register
             </button>
          </div>
        </div>

        {/* Student List */}
        <div className="border border-gray-200 rounded-xl overflow-hidden">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="p-3 font-bold text-gray-600">Roll No</th>
                <th className="p-3 font-bold text-gray-600">Student Name</th>
                <th className="p-3 font-bold text-gray-600 text-center">Status</th>
                <th className="p-3 font-bold text-gray-600 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {classStudents.map((s, idx) => {
                const status = attendanceRecords[s.id] || (idx % 4 === 0 ? 'Absent' : 'Present');
                return (
                <tr key={s.id} className="hover:bg-gray-50">
                  <td className="p-3 font-mono font-bold text-gray-600">{s.rollNumber}</td>
                  <td className="p-3 font-bold text-gray-900 flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-gray-200 overflow-hidden">
                       {s.photo ? <img src={s.photo} alt={s.name} className="w-full h-full object-cover" /> : null}
                    </div>
                    {s.name}
                  </td>
                  <td className="p-3 text-center">
                    <span className={`px-2 py-1 rounded text-[10px] font-black uppercase ${
                      status === 'Present' ? 'bg-emerald-100 text-emerald-700' : 
                      status === 'Absent' ? 'bg-rose-100 text-rose-700' :
                      'bg-amber-100 text-amber-700'
                    }`}>
                      {status}
                    </span>
                  </td>
                  <td className="p-3 text-right space-x-2">
                    <button onClick={() => setHistoryStudent(s)} className="px-2 py-1 bg-blue-50 text-blue-600 border border-blue-200 rounded text-xs font-bold hover:bg-blue-100">History</button>
                    <button onClick={() => handleMark(s.id, 'Present')} className="px-2 py-1 bg-emerald-50 text-emerald-600 border border-emerald-200 rounded text-xs font-bold hover:bg-emerald-100">P</button>
                    <button onClick={() => handleMark(s.id, 'Absent')} className="px-2 py-1 bg-rose-50 text-rose-600 border border-rose-200 rounded text-xs font-bold hover:bg-rose-100">A</button>
                    <button onClick={() => handleMark(s.id, 'Leave')} className="px-2 py-1 bg-amber-50 text-amber-600 border border-amber-200 rounded text-xs font-bold hover:bg-amber-100">L</button>
                  </td>
                </tr>
              )})}
              {classStudents.length === 0 && (
                <tr>
                  <td colSpan={4} className="p-8 text-center text-gray-500">No students found in this class.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        <div className="flex justify-end">
           <button className="px-6 py-2 bg-gray-900 text-white rounded-xl font-bold shadow-sm hover:bg-black">Save Attendance</button>
        </div>
      </div>

      {/* History Modal */}
      {historyStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-gray-900">Attendance History</h3>
              <button onClick={() => setHistoryStudent(null)} className="text-gray-400 hover:text-gray-600">✕</button>
            </div>
            <p className="text-sm text-gray-500 mb-6">History for <span className="font-bold text-gray-800">{historyStudent.name}</span> ({historyStudent.rollNumber})</p>
            
            <div className="space-y-4 max-h-[300px] overflow-y-auto">
              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl">
                <div>
                  <p className="font-bold text-gray-900">June 2026</p>
                  <p className="text-xs text-gray-500">Present: 22 Days, Absent: 2 Days, Leave: 1 Day</p>
                </div>
                <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-black uppercase rounded">91%</span>
              </div>
              <div className="flex items-center justify-between p-4 border border-gray-200 rounded-xl bg-gray-50">
                <div>
                  <p className="font-bold text-gray-900">May 2026</p>
                  <p className="text-xs text-gray-500">Present: 24 Days, Absent: 0 Days, Leave: 1 Day</p>
                </div>
                <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-black uppercase rounded">96%</span>
              </div>
            </div>
            
            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setHistoryStudent(null)}
                className="px-4 py-2 font-bold text-white bg-gray-900 hover:bg-black rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
