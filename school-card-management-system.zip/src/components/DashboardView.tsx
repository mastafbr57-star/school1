import React from 'react';
import { Users, GraduationCap, DollarSign, Calendar, Clock, BookOpen, AlertCircle, TrendingUp } from 'lucide-react';
import { Teacher, Student } from '../types';

interface DashboardViewProps {
  teachers: Teacher[];
  students: Student[];
  setActiveTab: (tab: any) => void;
  schoolName?: string;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ teachers, students, setActiveTab, schoolName = 'EduCard Pro' }) => {
  const activeStudents = students.filter(s => s.status === 'active').length;
  const activeTeachers = teachers.filter(t => t.status === 'active').length;
  
  const pendingFees = students.filter(s => s.feeStatus === 'pending' || s.feeStatus === 'overdue').length;

  return (
    <div className="w-full space-y-6 animate-fadeIn">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Dashboard Overview</h2>
          <p className="text-xs text-gray-500 mt-1">Welcome to {schoolName} Management System.</p>
        </div>
        <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-bold flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-blue-600"></span> Live System
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Widget 1 */}
        <div 
          onClick={() => setActiveTab('students')}
          className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow cursor-pointer flex items-center gap-4"
        >
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase">Total Students</p>
            <h4 className="text-2xl font-black text-gray-900">{activeStudents}</h4>
          </div>
        </div>

        {/* Widget 2 */}
        <div 
          onClick={() => setActiveTab('teachers')}
          className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow cursor-pointer flex items-center gap-4"
        >
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase">Total Teachers</p>
            <h4 className="text-2xl font-black text-gray-900">{activeTeachers}</h4>
          </div>
        </div>

        {/* Widget 3 */}
        <div 
          onClick={() => setActiveTab('fees')}
          className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow cursor-pointer flex items-center gap-4"
        >
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <DollarSign className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase">Pending Fees</p>
            <h4 className="text-2xl font-black text-gray-900">{pendingFees}</h4>
          </div>
        </div>

        {/* Widget 4 */}
        <div 
          onClick={() => setActiveTab('attendance')}
          className="bg-white p-5 rounded-2xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow cursor-pointer flex items-center gap-4"
        >
          <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
            <Calendar className="w-6 h-6" />
          </div>
          <div>
            <p className="text-xs font-bold text-gray-400 uppercase">Today's Attendance</p>
            <h4 className="text-2xl font-black text-gray-900">92%</h4>
          </div>
        </div>
      </div>

      {/* Quick Actions & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-gray-400" /> Quick Actions
          </h3>
          <div className="grid grid-cols-2 gap-3">
            <button onClick={() => setActiveTab('students')} className="p-3 text-left bg-gray-50 hover:bg-gray-100 rounded-xl border border-gray-200 font-bold text-sm text-gray-700">
              🎓 View All Students
            </button>
            <button onClick={() => setActiveTab('teachers')} className="p-3 text-left bg-gray-50 hover:bg-gray-100 rounded-xl border border-gray-200 font-bold text-sm text-gray-700">
              👨‍🏫 View All Teachers
            </button>
            <button onClick={() => setActiveTab('attendance')} className="p-3 text-left bg-gray-50 hover:bg-gray-100 rounded-xl border border-gray-200 font-bold text-sm text-gray-700">
              📅 Mark Attendance
            </button>
            <button onClick={() => setActiveTab('fees')} className="p-3 text-left bg-gray-50 hover:bg-gray-100 rounded-xl border border-gray-200 font-bold text-sm text-gray-700">
              💰 Collect Fees
            </button>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5 text-gray-400" /> Recent Announcements
          </h3>
          <div className="space-y-4">
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center flex-shrink-0">
                <BookOpen className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-gray-800">Mid-term Exams Scheduled</h4>
                <p className="text-xs text-gray-500 mt-0.5">Exams will commence from 15th July. All teachers must submit papers.</p>
              </div>
            </div>
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center flex-shrink-0">
                <AlertCircle className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-gray-800">Fee Reminder Sent</h4>
                <p className="text-xs text-gray-500 mt-0.5">Automated SMS sent to parents for pending June dues.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
