/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { Teacher, Student, RecordType, CardTheme, FilterOptions } from './types';
import { SCHOOL_INFO, INITIAL_TEACHERS, INITIAL_STUDENTS } from './data/mockData';
import { Sidebar, TabType } from './components/Sidebar';
import { Header } from './components/Header';
import { TeacherCard } from './components/TeacherCard';
import { StudentCard } from './components/StudentCard';
import { IdCardPreview } from './components/IdCardPreview';
import { StatsOverview } from './components/StatsOverview';
import { DashboardView } from './components/DashboardView';
import { AttendanceView } from './components/AttendanceView';
import { FeeManagementView } from './components/FeeManagementView';
import { ExamsView } from './components/ExamsView';
import { AddEditModal } from './components/AddEditModal';
import { ProfileDetailModal } from './components/ProfileDetailModal';
import { PrintBatchModal } from './components/PrintBatchModal';
import { Users, GraduationCap, Sparkles } from 'lucide-react';

export default function App() {
  // Navigation & View States
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [recordType, setRecordType] = useState<RecordType>('teacher');

  // Data Store States
  const [teachers, setTeachers] = useState<Teacher[]>(INITIAL_TEACHERS);
  const [students, setStudents] = useState<Student[]>(INITIAL_STUDENTS);

  // Card Theme State
  const [cardTheme, setCardTheme] = useState<CardTheme>('blue');

  // Filter & Search States
  const [searchTerm, setSearchTerm] = useState('');
  const [classFilter, setClassFilter] = useState('all');

  // Selection & Modal States
  const [selectedForIdRecord, setSelectedForIdRecord] = useState<Teacher | Student | null>(INITIAL_TEACHERS[0]);
  const [viewProfileRecord, setViewProfileRecord] = useState<Teacher | Student | null>(null);
  const [editingRecord, setEditingRecord] = useState<Teacher | Student | null>(null);
  const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
  const [isBatchPrintModalOpen, setIsBatchPrintModalOpen] = useState(false);
  
  // School settings state
  const [schoolName, setSchoolName] = useState('EduCard Pro');
  const [schoolTagline, setSchoolTagline] = useState('PAKISTAN SCHOOL SYS');

  // Load from local storage on mount
  useEffect(() => {
    const savedName = localStorage.getItem('schoolName');
    const savedTagline = localStorage.getItem('schoolTagline');
    if (savedName) setSchoolName(savedName);
    if (savedTagline) setSchoolTagline(savedTagline);
  }, []);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('schoolName', schoolName);
    localStorage.setItem('schoolTagline', schoolTagline);
  }, [schoolName, schoolTagline]);

  // Available unique classes for filter dropdown
  const availableClasses = useMemo(() => {
    const classesList = ['Prep', '1st', '2nd', '3rd', '4th', '5th', '6th', '7th', '8th', '9th', '10th', '11th', '12th'];
    const classesSet = new Set<string>(classesList);
    teachers.forEach((t) => classesSet.add(t.subject));
    students.forEach((s) => classesSet.add(s.classSection));
    return Array.from(classesSet).sort();
  }, [teachers, students]);

  // Filtered lists
  const filteredTeachers = useMemo(() => {
    return teachers.filter((t) => {
      const matchesSearch =
        t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.subject.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesClass = classFilter === 'all' || t.subject === classFilter;
      return matchesSearch && matchesClass;
    });
  }, [teachers, searchTerm, classFilter]);

  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      const matchesSearch =
        s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.rollNumber.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesClass = classFilter === 'all' || s.classSection.startsWith(classFilter);
      return matchesSearch && matchesClass;
    });
  }, [students, searchTerm, classFilter]);

  // Handle Export to CSV / Excel
  const handleExportExcel = () => {
    const records = recordType === 'teacher' ? filteredTeachers : filteredStudents;
    if (records.length === 0) return;

    const headers =
      recordType === 'teacher'
        ? ['ID', 'Full Name', 'Subject', 'Designation', 'Qualification', 'Experience', 'Class Incharge', 'Email', 'Phone', 'Status']
        : ['ID', 'Student Name', 'Roll No', 'Class & Section', 'Father Name', 'DOB', 'Blood Group', 'Fee Status', 'Attendance %', 'Result Summary', 'Parent Contact'];

    const csvRows = records.map((rec) => {
      if ('subject' in rec) {
        return [
          rec.id,
          `"${rec.name}"`,
          `"${rec.subject}"`,
          `"${rec.designation}"`,
          `"${rec.qualification}"`,
          `"${rec.experience}"`,
          `"${rec.classIncharge}"`,
          `"${rec.email}"`,
          `"${rec.phone || ''}"`,
          rec.status,
        ].join(',');
      } else {
        return [
          rec.id,
          `"${rec.name}"`,
          `"${rec.rollNumber}"`,
          `"${rec.classSection}"`,
          `"${rec.fatherName}"`,
          rec.dob,
          rec.bloodGroup,
          rec.feeStatus,
          `${rec.attendancePercentage}%`,
          `"${rec.resultSummary}"`,
          `"${rec.parentContact}"`,
        ].join(',');
      }
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...csvRows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${recordType}_records_export_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Save Handlers
  const handleSaveTeacher = (newT: Teacher) => {
    setTeachers((prev) => {
      const exists = prev.some((t) => t.id === newT.id);
      if (exists) {
        return prev.map((t) => (t.id === newT.id ? newT : t));
      } else {
        return [newT, ...prev];
      }
    });
    setSelectedForIdRecord(newT);
  };

  const handleSaveStudent = (newS: Student) => {
    setStudents((prev) => {
      const exists = prev.some((s) => s.id === newS.id);
      if (exists) {
        return prev.map((s) => (s.id === newS.id ? newS : s));
      } else {
        return [newS, ...prev];
      }
    });
    setSelectedForIdRecord(newS);
  };

  return (
    <div className="flex flex-col md:flex-row min-h-screen w-full bg-[#F3F4F6] text-[#111827] font-sans antialiased selection:bg-blue-600 selection:text-white">
      {/* Sidebar Navigation Container */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        setRecordType={setRecordType}
        teachersCount={teachers.length}
        studentsCount={students.length}
        schoolName={schoolName}
        setSchoolName={setSchoolName}
        schoolTagline={schoolTagline}
        setSchoolTagline={setSchoolTagline}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 overflow-x-hidden">
        {/* Header Search Bar & Actions */}
        <Header
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          onOpenAddModal={() => {
            setEditingRecord(null);
            setIsAddEditModalOpen(true);
          }}
          onOpenPrintBatch={() => setIsBatchPrintModalOpen(true)}
          onExportExcel={handleExportExcel}
          recordType={recordType}
          setRecordType={setRecordType}
          classFilter={classFilter}
          setClassFilter={setClassFilter}
          availableClasses={availableClasses}
        />

        {/* Content Body */}
        <div className="p-4 sm:p-6 md:p-8 flex flex-col lg:flex-row gap-8 flex-1 items-start">
          {activeTab === 'dashboard' && (
            <DashboardView teachers={teachers} students={students} setActiveTab={setActiveTab} schoolName={schoolName} />
          )}
          {activeTab === 'attendance' && (
            <AttendanceView students={students} />
          )}
          {activeTab === 'fees' && (
            <FeeManagementView students={students} onUpdateStudent={handleSaveStudent} schoolName={schoolName} />
          )}
          {activeTab === 'exams' && (
            <ExamsView students={students} onUpdateStudent={handleSaveStudent} />
          )}
          {activeTab === 'analytics' && (
            <div className="w-full">
              <StatsOverview teachers={teachers} students={students} />
            </div>
          )}
          {(activeTab === 'teachers' || activeTab === 'students' || activeTab === 'id-generator') && (
            <>
              {/* Active Profile Section (Left 60% relative flex container) */}
              <section className="flex-1 w-full space-y-6 print:hidden">
                {/* Section Title & Teacher/Student Switcher Pill */}
                <div className="flex flex-wrap items-center justify-between gap-4 border-b border-gray-200/80 pb-4">
                  <div>
                    <h2 className="text-2xl font-bold tracking-tight text-gray-900 flex items-center gap-2">
                      <span>{recordType === 'teacher' ? '👨‍🏫 Teacher Profiles' : '👨‍🎓 Student Profiles'}</span>
                    </h2>
                    <p className="text-xs text-gray-500 mt-1">
                      Showing {recordType === 'teacher' ? filteredTeachers.length : filteredStudents.length} active records from database.
                    </p>
                  </div>

                  {/* Clean Minimalism Toggle Button Group */}
                  <div className="flex bg-gray-200/80 p-1 rounded-xl text-xs font-bold shadow-inner">
                    <button
                      onClick={() => {
                        setRecordType('teacher');
                        if (filteredTeachers.length > 0) setSelectedForIdRecord(filteredTeachers[0]);
                      }}
                      className={`px-4 py-2.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                        recordType === 'teacher' ? 'bg-white shadow-xs text-blue-600' : 'text-gray-600 hover:text-gray-900'
                      }`}
                    >
                      <Users className="w-3.5 h-3.5" />
                      <span>Teachers ({filteredTeachers.length})</span>
                    </button>
                    <button
                      onClick={() => {
                        setRecordType('student');
                        if (filteredStudents.length > 0) setSelectedForIdRecord(filteredStudents[0]);
                      }}
                      className={`px-4 py-2.5 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                        recordType === 'student' ? 'bg-white shadow-xs text-emerald-600' : 'text-gray-600 hover:text-gray-900'
                      }`}
                    >
                      <GraduationCap className="w-3.5 h-3.5" />
                      <span>Students ({filteredStudents.length})</span>
                    </button>
                  </div>
                </div>

                {/* Profiles List */}
                <div className="space-y-4">
                  {recordType === 'teacher' ? (
                    filteredTeachers.length > 0 ? (
                      filteredTeachers.map((teacher) => (
                        <TeacherCard
                          key={teacher.id}
                          teacher={teacher}
                          isSelectedForId={selectedForIdRecord?.id === teacher.id}
                          onSelectForId={(t) => setSelectedForIdRecord(t)}
                          onViewProfile={(t) => setViewProfileRecord(t)}
                          onEdit={(t) => {
                            setEditingRecord(t);
                            setIsAddEditModalOpen(true);
                          }}
                        />
                      ))
                    ) : (
                      <div className="bg-white rounded-2xl p-12 text-center border border-gray-200 text-gray-500">
                        <p className="text-base font-bold">No Teacher Records Found</p>
                        <p className="text-xs mt-1">Try adjusting your search query or reset class filters.</p>
                      </div>
                    )
                  ) : filteredStudents.length > 0 ? (
                    filteredStudents.map((student) => (
                      <StudentCard
                        key={student.id}
                        student={student}
                        isSelectedForId={selectedForIdRecord?.id === student.id}
                        onView={(s) => setViewProfileRecord(s)}
                        onEdit={(s) => {
                          setEditingRecord(s);
                          setIsAddEditModalOpen(true);
                        }}
                        onPrintId={(s) => {
                          setSelectedForIdRecord(s);
                        }}
                      />
                    ))
                  ) : (
                    <div className="bg-white rounded-2xl p-12 text-center border border-gray-200 text-gray-500">
                      <p className="text-base font-bold">No Student Records Found</p>
                      <p className="text-xs mt-1">Try adjusting your search query or reset class filters.</p>
                    </div>
                  )}
                </div>
              </section>

              {/* Live ID Card Preview (Right 40% panel container) */}
              <IdCardPreview
                selectedRecord={selectedForIdRecord}
                schoolInfo={{ ...SCHOOL_INFO, name: schoolName, address: schoolTagline || SCHOOL_INFO.address }}
                theme={cardTheme}
                setTheme={setCardTheme}
                onOpenBatchPrint={() => setIsBatchPrintModalOpen(true)}
              />
            </>
          )}
        </div>
      </main>

      {/* Interactive Dialog Modals */}
      <AddEditModal
        isOpen={isAddEditModalOpen}
        onClose={() => setIsAddEditModalOpen(false)}
        onSaveTeacher={handleSaveTeacher}
        onSaveStudent={handleSaveStudent}
        recordType={recordType}
        editingRecord={editingRecord}
      />

      <ProfileDetailModal
        record={viewProfileRecord}
        onClose={() => setViewProfileRecord(null)}
      />

      <PrintBatchModal
        isOpen={isBatchPrintModalOpen}
        onClose={() => setIsBatchPrintModalOpen(false)}
        records={recordType === 'teacher' ? filteredTeachers : filteredStudents}
        schoolInfo={{ ...SCHOOL_INFO, name: schoolName, address: schoolTagline || SCHOOL_INFO.address }}
        theme={cardTheme}
      />
    </div>
  );
}

