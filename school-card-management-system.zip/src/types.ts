export type RecordType = 'teacher' | 'student';

export type CardTheme = 'blue' | 'green' | 'dark' | 'maroon' | 'amber';

export interface TimetableEntry {
  day: string;
  period: string;
  subject: string;
  classSection: string;
  room?: string;
}

export interface Teacher {
  id: string; // e.g. T-001
  name: string;
  photo: string;
  subject: string;
  designation: string;
  qualification: string;
  experience: string;
  phone?: string;
  email: string;
  classIncharge: string;
  joiningDate: string;
  status: 'active' | 'inactive';
  timetable: TimetableEntry[];
}

export interface Student {
  id: string; // e.g. S-1023
  name: string;
  photo: string;
  dob: string;
  fatherName: string;
  classSection: string;
  rollNumber: string;
  address: string;
  parentContact: string;
  emergencyContact: string;
  bloodGroup: string;
  feeStatus: 'paid' | 'pending' | 'overdue';
  feeMonth: string;
  feeAmount: number;
  feePaidAmount?: number;
  attendancePercentage: number;
  resultSummary: string; // e.g. "A+ Grade (92%)"
  status: 'active' | 'inactive';
}

export interface SchoolInfo {
  name: string;
  address: string;
  phone: string;
  email: string;
  logo: string;
  validity: string;
}

export interface FilterOptions {
  search: string;
  recordType: RecordType;
  classSection: string;
  status: string;
  feeStatus: string;
}
